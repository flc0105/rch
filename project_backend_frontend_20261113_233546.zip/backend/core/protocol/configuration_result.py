"""Typed presentation intent for Configuration Control results."""

from core.protocol.control import ConfigurationAction
from core.utils.command_output import ResultDisplay, ResultEventType


def build_configuration_result(action, *, status='success', message='', data=None):
    """Return one business result for both Web and CLI consumers."""
    if action not in (ConfigurationAction.GET, ConfigurationAction.SET, ConfigurationAction.RESET):
        raise ValueError('Invalid Configuration action')
    display = ResultDisplay.DATA if action == ConfigurationAction.GET and status == 'success' else ResultDisplay.MESSAGE
    result = {'event_type': ResultEventType.COMPLETED, 'status': status,
              'display': display, 'message': str(message)}
    if display == ResultDisplay.DATA:
        if not isinstance(data, dict) or not isinstance(data.get('items'), list):
            raise ValueError('Configuration GET requires a configuration payload')
        result['data'] = data
    return result
