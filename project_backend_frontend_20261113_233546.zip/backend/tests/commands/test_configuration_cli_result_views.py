"""Configuration CLI result presentation uses one five-column view of full Control data."""
import json
from types import SimpleNamespace

import pytest

from core.protocol.control import ConfigurationAction
from core.protocol.configuration_result import build_configuration_result
from core.utils.configuration_cli import parse_configuration_request
from server.application.command.configuration_builtin_support import ConfigurationBuiltinSupport
from core.utils.configuration_cli import configuration_cli_items


FULL_CONFIG = {
    'store_path': '/tmp/client/runtime_config.json',
    'pruned': ['OLD_REDUNDANT'],
    'items': [
        {'key': 'SCRIPT_DEFAULT_OUTPUT_MODE', 'group': 'Script', 'value': 'stream',
         'source': 'override', 'default_value': 'collect', 'desc': 'output mode',
         'value_type': 'str', 'choices': ['stream', 'collect'], 'min_value': None,
         'max_value': None, 'step': None, 'editable': True},
        {'key': 'HTTP_TRANSFER_MODE', 'group': 'Transfer', 'value': 'cancelable',
         'source': 'default', 'default_value': 'cancelable', 'desc': 'transfer mode',
         'value_type': 'str', 'choices': ['cancelable'], 'min_value': None,
         'max_value': None, 'step': None, 'editable': True},
    ],
}


class Remote:
    def __init__(self, result=None, *, status=1, progress=()):
        self.result = build_configuration_result(ConfigurationAction.GET, data=FULL_CONFIG) if result is None else result
        self.status = status
        self.progress = progress
        self.calls = []

    def stream_command(self, conn, command, **kwargs):
        self.calls.append(kwargs)
        from core.protocol.message_queue import ResultChunk
        for msg in self.progress:
            yield ResultChunk(1, msg, False)
        yield ResultChunk(self.status, self.result, True)


def support_for(remote):
    conn = SimpleNamespace(session_info=SimpleNamespace(os_alias='linux'))
    return ConfigurationBuiltinSupport(conn, remote, lambda: '')


def test_configuration_projection_is_five_fields_and_does_not_mutate_web_payload():
    before = json.dumps(FULL_CONFIG, sort_keys=True)
    rows = configuration_cli_items(FULL_CONFIG)
    assert rows == [
        {'key': 'SCRIPT_DEFAULT_OUTPUT_MODE', 'group': 'Script', 'value': 'stream',
         'override': True, 'default_value': 'collect'},
        {'key': 'HTTP_TRANSFER_MODE', 'group': 'Transfer', 'value': 'cancelable',
         'override': False, 'default_value': 'cancelable'},
    ]
    assert json.dumps(FULL_CONFIG, sort_keys=True) == before
    assert FULL_CONFIG['items'][0]['choices'] == ['stream', 'collect']


def test_set_text_and_json_share_exact_five_fields():
    remote = Remote()
    support = support_for(remote)
    text = list(support.set(''))
    output = list(support.set('--json'))
    assert len(text) == len(output) == 1
    assert text[0][0] == output[0][0] == 1
    assert json.loads(output[0][1]) == configuration_cli_items(FULL_CONFIG)
    lines = text[0][1]
    for field in ('key', 'group', 'value', 'override', 'default_value'):
        assert field in lines
    for unwanted in ('choices', 'value_type', 'editable', 'min_value', 'max_value', 'store_path', 'desc', 'source'):
        assert unwanted not in lines
        assert unwanted not in output[0][1]
    assert remote.calls[-1]['action'] == ConfigurationAction.GET


def test_set_all_keeps_include_hidden_but_uses_same_projection():
    remote = Remote()
    result = list(support_for(remote).set('--all --json'))
    assert json.loads(result[0][1]) == configuration_cli_items(FULL_CONFIG)
    assert remote.calls[0]['payload'] == {'include_hidden': True}


@pytest.mark.parametrize('command,action,payload', [
    ('--json', ConfigurationAction.GET, {}),
    ('--all --json', ConfigurationAction.GET, {'include_hidden': True}),
    ('SCRIPT_DEFAULT_OUTPUT_MODE stream --json', ConfigurationAction.SET,
     {'key': 'SCRIPT_DEFAULT_OUTPUT_MODE', 'value': 'stream', 'value_format': 'text'}),
    ('--reset SCRIPT_DEFAULT_OUTPUT_MODE --json', ConfigurationAction.RESET,
     {'key': 'SCRIPT_DEFAULT_OUTPUT_MODE'}),
    ('--reset-all --json', ConfigurationAction.RESET, {'all': True}),
    ('SCRIPT_DEFAULT_OUTPUT_MODE json', ConfigurationAction.SET,
     {'key': 'SCRIPT_DEFAULT_OUTPUT_MODE', 'value': 'json', 'value_format': 'text'}),
    ('SCRIPT_DEFAULT_OUTPUT_MODE --json', ConfigurationAction.SET,
     {'key': 'SCRIPT_DEFAULT_OUTPUT_MODE', 'value': '--json', 'value_format': 'text'}),
])
def test_configuration_parser(command, action, payload):
    parsed_action, parsed_payload, output_format = parse_configuration_request(command)
    assert parsed_action == action
    assert parsed_payload == payload
    assert output_format == ('text' if command.endswith((' json', ' --json')) and
                             command.startswith('SCRIPT_DEFAULT_OUTPUT_MODE') and
                             command.count(' ') == 1 else 'json')


def test_set_mutation_uses_only_status_message_even_with_full_client_payload():
    payload = {**FULL_CONFIG, 'change': {'key': 'SCRIPT_DEFAULT_OUTPUT_MODE',
                                       'old_value': 'collect', 'new_value': 'stream'}}
    support = support_for(Remote(build_configuration_result(ConfigurationAction.SET, message="SCRIPT_DEFAULT_OUTPUT_MODE updated: 'collect' → 'stream'"), progress=['Applied effect']))
    text = list(support.set('SCRIPT_DEFAULT_OUTPUT_MODE stream'))
    assert [item[1] for item in text] == ['Applied effect',
                                           "SCRIPT_DEFAULT_OUTPUT_MODE updated: 'collect' → 'stream'"]
    output = list(support.set('SCRIPT_DEFAULT_OUTPUT_MODE stream --json'))
    assert len(output) == 1
    assert json.loads(output[0][1]) == {'status': 'success',
                                        'message': "SCRIPT_DEFAULT_OUTPUT_MODE updated: 'collect' → 'stream'"}


@pytest.mark.parametrize('command,payload,message', [
    ('--reset SCRIPT_DEFAULT_OUTPUT_MODE --json',
     {**FULL_CONFIG, 'change': {'key': 'SCRIPT_DEFAULT_OUTPUT_MODE',
                               'old_value': 'stream', 'new_value': 'collect'}},
     "SCRIPT_DEFAULT_OUTPUT_MODE reset to default: 'collect'"),
    ('--reset-all --json', FULL_CONFIG, 'All runtime config overrides reset to defaults.'),
])
def test_reset_json_feedback_has_no_full_ui_metadata(command, payload, message):
    output = list(support_for(Remote(build_configuration_result(ConfigurationAction.RESET, message=message))).set(command))
    assert len(output) == 1
    assert json.loads(output[0][1]) == {'status': 'success', 'message': message}


def test_set_json_validation_and_client_error_have_same_status_message_contract():
    invalid = list(support_for(Remote()).set('--reset --json'))
    failed = list(support_for(Remote(build_configuration_result(ConfigurationAction.GET, status='error', message='Unknown config key'), status=0)).set('--json'))
    assert json.loads(invalid[0][1]) == {
        'status': 'error', 'message': 'Usage: set --reset KEY [--json]'}
    assert json.loads(failed[0][1]) == {'status': 'error', 'message': 'Unknown config key'}


def test_set_empty_config_shows_empty_view_and_json_array():
    result = {'items': [], 'store_path': '/tmp/file.json'}
    text = list(support_for(Remote(build_configuration_result(ConfigurationAction.GET, data=result))).set(''))
    data = list(support_for(Remote(build_configuration_result(ConfigurationAction.GET, data=result))).set('--json'))
    assert text[0][1] == 'No data to display'
    assert json.loads(data[0][1]) == []
