"""Actual TCP forwarding and instance lifecycle for both exposed sides."""
import http.server
import socket
import threading
from types import SimpleNamespace
from urllib.request import Request, urlopen

import pytest

from client.config.config import RUNTIME_CONFIG
from core.protocol.control import ControlDomain
from server.persistence.rch_database import RchDatabase
from tunnel.client import ClientTunnel
from tunnel.instances import TunnelInstanceService
from tunnel.server import ServerTunnels


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


@pytest.fixture
def target():
    from test_tunnel_v27 import ApiHandler
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), ApiHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server.server_address[1]
    finally:
        server.shutdown()
        server.server_close()


@pytest.fixture
def environment(tmp_path, monkeypatch):
    from tunnel import client as client_module
    client_ingress = ClientTunnel()
    client_target = ServerTunnels()
    monkeypatch.setattr(client_module, '_manager', client_ingress)
    monkeypatch.setattr(client_module, '_target_manager', client_target)
    monkeypatch.setitem(RUNTIME_CONFIG, 'connection_mode', 'reverse')
    monkeypatch.setitem(RUNTIME_CONFIG, 'server_host', '127.0.0.1')
    session = SimpleNamespace(listener_protocol='tcp',
                              bind_dial_endpoint=('127.0.0.1', free_port()),
                              session_info=SimpleNamespace(client_id='device-1'))

    class Remote:
        def run_foreground_control(self, conn, domain, action, payload, **kwargs):
            assert conn is session
            assert domain is ControlDomain.TUNNEL
            return client_module.execute(SimpleNamespace(_checkpoint=lambda: None), action, payload)

    server = SimpleNamespace(database=RchDatabase(str(tmp_path / 'tunnel-v29.db')),
                             get_target_connection_by_client_id=lambda cid: session)
    service = TunnelInstanceService(server)
    try:
        yield service, Remote(), server, client_ingress, client_target, session
    finally:
        for name in tuple(client_ingress._fronts):
            client_ingress.stop(name)
        for peer in tuple(client_target._peers.values()):
            peer.close()
        for peer in tuple(service.runtime._peers.values()):
            peer.close()
        for client_id in tuple(service.server_exposed._clients):
            service.server_exposed._close_all(client_id)


def config(side, front, target, channel):
    return dict(expose_on=side, listen_host='127.0.0.1', listen_port=front,
                target_host='127.0.0.1', target_port=target, channel_port=channel)


def test_reverse_client_server_expose_http_large_post_and_restart(environment, target):
    service, remote, server, client, target_peer, session = environment
    front, channel = free_port(), free_port()
    created = service.create('device-1', 'mac-web', config('server', front, target, channel))
    assert created['expose_on'] == 'server'
    assert created['status'] == 'stopped'
    running = service.start('device-1', 'mac-web', remote)
    assert running['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{front}/from-server').read() == b'RCH:/from-server'
    body = bytes(range(256)) * 32768
    assert urlopen(Request(f'http://127.0.0.1:{front}/file', data=body, method='POST'), timeout=15).read() == body
    assert service.restart('device-1', 'mac-web', remote)['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{front}/restarted').read() == b'RCH:/restarted'
    assert service.stop('device-1', 'mac-web', remote)['status'] == 'stopped'
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(('127.0.0.1', front))


def test_two_exposed_sides_are_independent(environment, target):
    service, remote, server, client, target_peer, session = environment
    front1, front2, channel, client_channel = free_port(), free_port(), free_port(), free_port()
    # Both endpoints run on localhost in this test; production runs them on separate machines.
    service.create('device-1', 'server-side', config('server', front1, target, channel))
    service.create('device-1', 'client-side', config('client', front2, target, client_channel))
    assert service.start('device-1', 'server-side', remote)['status'] == 'running'
    assert service.start('device-1', 'client-side', remote)['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{front1}/server').read() == b'RCH:/server'
    assert urlopen(f'http://127.0.0.1:{front2}/client').read() == b'RCH:/client'
    assert service.stop('device-1', 'server-side', remote)['status'] == 'stopped'
    assert urlopen(f'http://127.0.0.1:{front2}/untouched').read() == b'RCH:/untouched'
    service.stop('device-1', 'client-side', remote)


def test_server_expose_shared_channel_and_conflicts(environment, target):
    service, remote, server, client, target_peer, session = environment
    front, another, channel = free_port(), free_port(), free_port()
    service.create('device-1', 'first', config('server', front, target, channel))
    service.create('device-1', 'second', config('server', another, target, channel))
    with pytest.raises(ValueError, match='already assigned'):
        service.create('device-1', 'conflict', config('server', front, target, channel))
    with pytest.raises(ValueError, match='share the same'):
        service.create('device-1', 'other-channel', config('server', free_port(), target, free_port()))
    service.start('device-1', 'first', remote)
    service.start('device-1', 'second', remote)
    assert urlopen(f'http://127.0.0.1:{another}/two').read() == b'RCH:/two'
    service.stop('device-1', 'first', remote)
    assert urlopen(f'http://127.0.0.1:{another}/still-two').read() == b'RCH:/still-two'
    service.stop('device-1', 'second', remote)


def test_server_exposed_configuration_persists_after_server_restart(environment, target):
    service, remote, server, client, target_peer, session = environment
    front, channel = free_port(), free_port()
    service.create('device-1', 'persistent', config('server', front, target, channel))
    replacement = SimpleNamespace(database=server.database,
                                  get_target_connection_by_client_id=lambda _: session)
    saved = TunnelInstanceService(replacement)
    assert saved.status('device-1', 'persistent')['status'] == 'stopped'
    assert saved.status('device-1', 'persistent')['expose_on'] == 'server'
    assert saved.start('device-1', 'persistent', remote)['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{front}/saved').read() == b'RCH:/saved'
    saved.stop('device-1', 'persistent', remote)


def test_server_exposed_rejects_unreachable_control_endpoint(environment, target, monkeypatch):
    service, remote, server, client, target_peer, session = environment
    front, channel = free_port(), free_port()
    service.create('device-1', 'bad', config('server', front, target, channel))
    monkeypatch.setitem(RUNTIME_CONFIG, 'server_host', '203.0.113.1')
    with pytest.raises(RuntimeError):
        service.start('device-1', 'bad', remote)
    assert service.status('device-1', 'bad')['status'] == 'stopped'


def test_restart_after_last_server_exposed_mapping_is_stopped(environment, target):
    service, remote, server, client, target_peer, session = environment
    port, channel = free_port(), free_port()
    service.create('device-1', 'retry', config('server', port, target, channel))
    service.start('device-1', 'retry', remote)
    service.stop('device-1', 'retry', remote)
    # Starting immediately must not reuse the former Server token/control socket.
    assert service.start('device-1', 'retry', remote)['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{port}/again').read() == b'RCH:/again'
    service.stop('device-1', 'retry', remote)


def test_cli_server_expose_and_no_bind_mode_check(environment, target):
    from server.application.command.tunnel_builtin_support import TunnelBuiltinSupport
    from server.application.command.server_builtin_registry import SERVER_COMMAND_REGISTRY
    service, remote, server, client, target_peer, session = environment
    cli = TunnelBuiltinSupport(server, session, remote, lambda: '')
    port, channel = free_port(), free_port()

    def invoke(text):
        parsed = SERVER_COMMAND_REGISTRY.parse_invocation('tunnel', text)
        return cli.execute(parsed)

    status, response = invoke(f'create --name tunnel-server --expose-on server '
                              f'--listen-port {port} --target-port {target} --channel-port {channel}')
    assert status == 1, response
    assert service.status('device-1', 'tunnel-server')['expose_on'] == 'server'
    status, response = invoke('start --name tunnel-server')
    assert status == 1, response
    assert urlopen(f'http://127.0.0.1:{port}/cli').read() == b'RCH:/cli'
    assert invoke('stop --name tunnel-server')[0] == 1
    assert invoke('remove --name tunnel-server')[0] == 1


def test_reverse_session_disconnect_does_not_close_tunnel(environment, target):
    service, remote, server, client, target_peer, session = environment
    port, channel = free_port(), free_port()
    service.create('device-1', 'survive', config('server', port, target, channel))
    service.start('device-1', 'survive', remote)
    server.get_target_connection_by_client_id = lambda _: (_ for _ in ()).throw(ValueError('offline'))
    assert urlopen(f'http://127.0.0.1:{port}/still-online').read() == b'RCH:/still-online'
    assert service.list('device-1')['instances'][0]['status'] == 'running'
    server.get_target_connection_by_client_id = lambda _: session
    service.stop('device-1', 'survive', remote)


def test_optional_expose_on_defaults_to_client_for_saved_instances(environment, target):
    service, remote, server, client, target_peer, session = environment
    port, channel = free_port(), free_port()
    saved = config('client', port, target, channel)
    del saved['expose_on']
    service.settings.write({'device-1': {'previous': saved}})
    item = service.status('device-1', 'previous')
    assert item['expose_on'] == 'client'
    assert service.start('device-1', 'previous', remote)['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{port}/previous').read() == b'RCH:/previous'
    service.stop('device-1', 'previous', remote)
