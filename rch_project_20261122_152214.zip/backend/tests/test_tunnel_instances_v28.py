"""Saved Tunnel lifecycle and v27 socket-level forwarding integration."""
import socket
import time
import threading
import http.server
from types import SimpleNamespace
from urllib.request import urlopen

import pytest

from client.config.config import RUNTIME_CONFIG
from core.protocol.control import ControlDomain
from server.persistence.rch_database import RchDatabase
from tunnel.client import ClientTunnel
from tunnel.instances import TunnelInstanceService
from tunnel.server import ServerTunnels


@pytest.fixture
def target():
    from test_tunnel_v27 import ApiHandler
    web = http.server.ThreadingHTTPServer(('127.0.0.1', 0), ApiHandler)
    thread = threading.Thread(target=web.serve_forever, daemon=True)
    thread.start()
    try:
        yield web.server_address[1]
    finally:
        web.shutdown()
        web.server_close()


def unused_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


@pytest.fixture
def agent(monkeypatch, tmp_path):
    from tunnel import client as client_module
    client = ClientTunnel()
    monkeypatch.setattr(client_module, '_manager', client)
    monkeypatch.setitem(RUNTIME_CONFIG, 'connection_mode', 'bind')
    session = SimpleNamespace(
        listener_protocol='bind_tcp', bind_dial_endpoint=('127.0.0.1', 9443),
        session_info=SimpleNamespace(client_id='device-1'),
    )
    database_path = str(tmp_path / 'tunnel-instances.sqlite')

    def server():
        return SimpleNamespace(
            database=RchDatabase(database_path),
            get_target_connection_by_client_id=lambda _: session,
        )

    class Remote:
        def run_foreground_control(self, connection, domain, action, payload, **kwargs):
            assert connection is session and domain == ControlDomain.TUNNEL
            return client_module.execute(SimpleNamespace(_checkpoint=lambda: None), action, payload)

    created_servers = []
    try:
        def fresh():
            value = server()
            created_servers.append(value)
            return value
        yield fresh, Remote(), session, client
    finally:
        for name in list(client._fronts):
            client.stop(name)
        for value in created_servers:
            peer = getattr(value, '_tcp_tunnels', None)
            if peer:
                active = peer.peer('device-1')
                if active:
                    active.close()


def config(front, target, channel):
    return dict(listen_host='127.0.0.1', listen_port=front,
                target_host='127.0.0.1', target_port=target,
                channel_port=channel)


def test_saved_instance_lifecycle_and_database_restart(agent, target):
    fresh, remote, session, client = agent
    server = fresh()
    service = TunnelInstanceService(server)
    front, channel = unused_port(), unused_port()
    saved = service.create('device-1', 'web', config(front, target, channel))
    assert saved['status'] == 'stopped'
    assert not client._fronts
    assert service.list('device-1')['instances'][0]['name'] == 'web'
    assert service.start('device-1', 'web', remote)['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{front}/first').read() == b'RCH:/first'
    with pytest.raises(ValueError, match='Stop the tunnel'):
        service.edit('device-1', 'web', {'target_port': target})
    with pytest.raises(ValueError, match='Stop the tunnel'):
        service.remove('device-1', 'web')
    assert service.restart('device-1', 'web', remote)['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{front}/restarted').read() == b'RCH:/restarted'
    assert service.stop('device-1', 'web', remote)['status'] == 'stopped'
    service.edit('device-1', 'web', {'listen_port': unused_port()})
    assert service.status('device-1', 'web')['target_port'] == target

    # Reconstruct Server with the same real sqlite store: saved, not autostarted.
    replacement = fresh()
    persisted = TunnelInstanceService(replacement)
    assert persisted.status('device-1', 'web')['status'] == 'stopped'
    assert not hasattr(replacement, '_tcp_tunnels') or not replacement._tcp_tunnels.list('device-1')['mappings']
    assert persisted.remove('device-1', 'web') == {'name': 'web', 'deleted': True}
    assert persisted.list('device-1')['instances'] == []


def test_channel_sharing_and_conflict_validation(agent, target):
    fresh, remote, session, client = agent
    service = TunnelInstanceService(fresh())
    channel, one, two = unused_port(), unused_port(), unused_port()
    service.create('device-1', 'first', config(one, target, channel))
    with pytest.raises(ValueError, match='already assigned'):
        service.create('device-1', 'duplicate', config(one, target, channel))
    with pytest.raises(ValueError, match='share the same'):
        service.create('device-1', 'different', config(two, target, unused_port()))
    with pytest.raises(ValueError, match='Mapping name'):
        service.create('device-1', '../bad', config(two, target, channel))
    with pytest.raises(ValueError, match='port'):
        service.create('device-1', 'badport', config(two, target, 0))

    service.create('device-1', 'second', config(two, target, channel))
    service.start('device-1', 'first', remote)
    service.start('device-1', 'second', remote)
    assert len(service.list('device-1')['instances']) == 2
    assert urlopen(f'http://127.0.0.1:{one}/a').read() == b'RCH:/a'
    assert urlopen(f'http://127.0.0.1:{two}/b').read() == b'RCH:/b'
    service.stop('device-1', 'first', remote)
    assert urlopen(f'http://127.0.0.1:{two}/still-works').read() == b'RCH:/still-works'
    assert service.stop_all('device-1', remote)['stopped'] == ['second']
    assert all(row['status'] == 'stopped' for row in service.list('device-1')['instances'])


def test_process_reconnect_and_server_reboot_same_mapping(agent, target):
    fresh, remote, session, client = agent
    first_server = fresh()
    service = TunnelInstanceService(first_server)
    front, channel = unused_port(), unused_port()
    service.create('device-1', 'api', config(front, target, channel))
    service.start('device-1', 'api', remote)
    assert urlopen(f'http://127.0.0.1:{front}/before-disconnect').read() == b'RCH:/before-disconnect'
    # A Bind RCH session reconnect does not touch the process-scoped Tunnel.
    session.session_info.client_id = 'device-1'
    assert urlopen(f'http://127.0.0.1:{front}/after-reconnect').read() == b'RCH:/after-reconnect'

    # Server process closes its peer while the Client process is retained.
    first_server._tcp_tunnels.peer('device-1').close()
    for _ in range(100):
        with client._lock:
            if client._control is None:
                break
        time.sleep(0.01)
    replacement = fresh()
    saved = TunnelInstanceService(replacement)
    assert saved.status('device-1', 'api')['status'] == 'stopped'
    assert saved.start('device-1', 'api', remote)['status'] == 'running'
    assert urlopen(f'http://127.0.0.1:{front}/after-server-restart').read() == b'RCH:/after-server-restart'
    saved.stop('device-1', 'api', remote)


def test_offline_start_does_not_remove_saved_configuration(agent, target):
    fresh, remote, session, client = agent
    server = fresh()
    service = TunnelInstanceService(server)
    service.create('device-1', 'offline', config(unused_port(), target, unused_port()))
    server.get_target_connection_by_client_id = lambda _: (_ for _ in ()).throw(ValueError('offline'))
    with pytest.raises(ValueError, match='offline'):
        service.start('device-1', 'offline', remote)
    assert service.status('device-1', 'offline')['status'] == 'stopped'


def test_cli_and_instance_service_share_saved_state(agent, target):
    from server.application.command.tunnel_builtin_support import TunnelBuiltinSupport
    from server.application.command.server_builtin_registry import SERVER_COMMAND_REGISTRY
    fresh, remote, session, _client = agent
    server = fresh()
    service = TunnelInstanceService(server)
    cli = TunnelBuiltinSupport(server, session, remote, lambda: '')

    def invoke(command):
        parsed = SERVER_COMMAND_REGISTRY.parse_invocation('tunnel', command)
        return cli.execute(parsed)

    front, channel = unused_port(), unused_port()
    status, output = invoke(f'create --name cli-web --listen-port {front} --target-port {target} --channel-port {channel}')
    assert status == 1, output
    assert service.status('device-1', 'cli-web')['status'] == 'stopped'
    status, output = invoke('start --name cli-web')
    assert status == 1, output
    assert urlopen(f'http://127.0.0.1:{front}/cli').read() == b'RCH:/cli'
    assert invoke('restart --name cli-web')[0] == 1
    assert invoke('stop --name cli-web')[0] == 1
    assert invoke(f'edit --name cli-web --target-port {target}')[0] == 1
    assert invoke('remove --name cli-web')[0] == 1
    assert service.list('device-1')['instances'] == []
