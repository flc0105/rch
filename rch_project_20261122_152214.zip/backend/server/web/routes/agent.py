import os
import hashlib

from core.agent_build_contract import AgentBuilderKind
from server.config.config import SOCKET_PORT, WEB_PORT
from flask import Blueprint, send_file

from server.web.api_response import WebApiResponder
from server.web.auth_guard import allow_anonymous
from server.web.request_parsers import get_json_payload

def _remove_temp_file(file_path: str):
    try:
        if file_path and os.path.isfile(file_path):
            os.remove(file_path)
    except OSError:
        pass


def create_agent_blueprint(server_instance):
    blueprint = Blueprint('agent', __name__)
    web_service = server_instance.web_service
    agent_api = web_service.agent_api
    responder = WebApiResponder()

    @blueprint.post('/api/agent/build')
    @allow_anonymous
    def build_agent():
        """构建 Agent"""

        def _execute():
            payload = get_json_payload()
            server_host = (payload.get('server_host') or '').strip()
            server_port = payload.get('server_port')
            web_port = payload.get('web_port')
            target_os = (payload.get('target_os') or 'mac').strip()
            builder = str(payload.get('builder') or '').strip()
            if not builder:
                raise ValueError('builder is required')
            target_arch = (payload.get('target_arch') or '').strip()
            server_web_scheme = (payload.get('server_web_scheme') or 'http').strip() or 'http'
            source = (payload.get('source') or 'manual').strip() or 'manual'
            connection_mode = str(payload.get('connection_mode') or 'reverse').strip().lower()
            server_web_host = str(payload.get('server_web_host') or (server_host if connection_mode == 'reverse' else '')).strip()
            bind_host = str(payload.get('bind_host') or '0.0.0.0').strip()
            try:
                bind_port = int(payload.get('bind_port', 9443))
            except (TypeError, ValueError):
                raise ValueError('bind_port must be integer')

            if connection_mode == 'bind':
                # Bind Bundle has no Server endpoint; only the session supplies one.
                server_host = ''
                server_port = SOCKET_PORT
                server_web_host = ''
                web_port = WEB_PORT
            elif not server_host:
                raise ValueError('server_host is required')
            elif not server_port:
                raise ValueError('server_port is required')
            if connection_mode != 'bind' and not web_port:
                raise ValueError('web_port is required')

            try:
                server_port = int(server_port)
            except ValueError:
                raise ValueError('server_port must be integer')
            if not 1 <= server_port <= 65535:
                raise ValueError('server_port must be between 1 and 65535')

            try:
                web_port = int(web_port)
            except ValueError:
                raise ValueError('web_port must be integer')

            listener_id = str(payload.get('listener_id') or '').strip()
            listener_protocol = 'tcp'
            tls_fingerprint = ''
            listener_name = ''
            if source == 'update' and connection_mode == 'bind':
                raise ValueError('Bind update requires manual port handoff')
            if connection_mode == 'bind' and listener_id:
                raise ValueError('Bind Agent does not use a Server listener')
            if source == 'update':
                settings = server_instance.listener_manager.update_build_settings(
                    str(payload.get('server_transport') or 'tcp').strip(),
                    str(payload.get('server_tls_fingerprint') or '').strip().lower(),
                    builder,
                    listener_id,
                )
                listener_id = settings['listener_id']
                listener_name = settings['listener_name']
                listener_protocol = settings['listener_protocol']
                tls_fingerprint = settings['tls_fingerprint']
            elif listener_id:
                settings = server_instance.listener_manager.build_settings(listener_id, server_port, builder)
                listener_name = server_instance.listener_manager.get(listener_id)['name']
                listener_protocol = settings['listener_protocol']
                tls_fingerprint = settings['tls_fingerprint']

            result = agent_api.build_agent(
                server_host,
                server_port,
                web_port,
                target_os,
                builder,
                target_arch,
                server_web_scheme,
                server_web_host,
                source,
                listener_protocol=listener_protocol,
                tls_fingerprint=tls_fingerprint,
                listener_id=listener_id,
                listener_name=listener_name,
                connection_mode=connection_mode, bind_host=bind_host, bind_port=bind_port,
            )
            result['download_url'] = f'/api/agent/download/{result["file_name"]}'
            if builder == AgentBuilderKind.PYTHON.value:
                digest = hashlib.sha256()
                with open(agent_api.get_built_agent_file_path(result['file_name']), 'rb') as artifact:
                    for chunk in iter(lambda: artifact.read(1024 * 1024), b''):
                        digest.update(chunk)
                result['sha256'] = digest.hexdigest()
            return result

        return responder.json_endpoint(_execute, default_error_status=500)

    @blueprint.get('/api/agent/outputs')
    def list_agent_outputs():
        return responder.json_endpoint(
            lambda: agent_api.list_agent_outputs(),
            default_error_status=500,
        )

    @blueprint.delete('/api/agent/outputs/<filename>')
    def delete_agent_output(filename):
        return responder.json_endpoint(
            lambda: agent_api.delete_agent_output(filename),
            default_error_status=500,
        )

    @blueprint.get('/api/agent/download/<filename>')
    @allow_anonymous
    def download_agent(filename):
        """下载构建好的 Agent"""
        try:
            file_path = agent_api.get_built_agent_file_path(filename)
            return send_file(
                file_path,
                as_attachment=True,
                download_name=filename,
            )
        except FileNotFoundError as e:
            return responder.fail(str(e), 404)
        except Exception as e:
            return responder.map_common_error(e)

    @blueprint.get('/api/agent/platform')
    def get_agent_platform():
        return responder.json_endpoint(
            lambda: agent_api.get_server_platform(),
            default_error_status=500,
        )

    @blueprint.post('/api/agent/loader/report')
    @allow_anonymous
    def ingest_loader_report():
        return responder.json_endpoint(
            lambda: agent_api.ingest_loader_report(get_json_payload()),
            default_error_status=500,
        )

    @blueprint.post('/api/agent/bootstrap')
    @allow_anonymous
    def generate_bootstrap():
        file_info = None
        try:
            file_info = agent_api.generate_bootstrap_file(get_json_payload())
            response = send_file(
                file_info['file_path'],
                as_attachment=True,
                download_name=file_info['download_name'],
                mimetype=file_info['mimetype'],
            )
            response.call_on_close(lambda: _remove_temp_file(file_info['file_path']))
            return response
        except Exception as e:
            if file_info:
                _remove_temp_file(file_info.get('file_path') or '')
            return responder.map_common_error(e)

    @blueprint.post('/api/agent/bootstrap/ps1')
    @allow_anonymous
    def generate_bootstrap_ps1():
        file_info = None
        try:
            file_info = agent_api.generate_bootstrap_ps1_file(get_json_payload())
            response = send_file(
                file_info['file_path'],
                as_attachment=True,
                download_name=file_info['download_name'],
                mimetype=file_info['mimetype'],
            )
            response.call_on_close(lambda: _remove_temp_file(file_info['file_path']))
            return response
        except Exception as e:
            if file_info:
                _remove_temp_file(file_info.get('file_path') or '')
            return responder.map_common_error(e)

    return blueprint
