import threading
import shlex

from core.protocol.message_types import MSG_TYPE_TRANSFER_CANCEL
from core.protocol.control import ControlRequest
from server.application.connection.control_command_store import HTTP_CONTROL_COMMANDS
from dataclasses import dataclass, field

from server.application.execution.execution_context import TaskExecutionContext
from server.application.tasks.task_types import TASK_TYPE_COMMAND, TASK_TYPE_UPLOAD


@dataclass
class WebExecutionTaskRequest:
    """
    统一 Web 执行请求。

    说明：
    - command / upload 都通过同一条任务创建主链进入
    - runner_name 决定最终交给哪个 task runner 方法
    """

    client_id: str
    command: str
    task_type: str
    runner_name: str
    tab_id: str = ''
    source: str = 'web'
    metadata: dict = field(default_factory=dict)
    use_foreground_guard: bool = True
    control: ControlRequest | None = None


class WebTaskService:
    """
    Web 任务服务。

    职责：
    - 提交并登记 Web 命令 / 上传任务
    - 占用前台执行槽
    - 启动 runner 真正执行
    - Web upload 使用独立 TransferManager 时不占 foreground；普通 Web command 保持原规则
    """

    def __init__(self, server, task_store, file_service, task_runner, transfer_service=None):
        self.server = server
        self.task_store = task_store
        self.file_service = file_service
        self.task_runner = task_runner
        self.transfer_service = transfer_service
        self.activity_coordinator = self.server.activity_coordinator

    def _create_task_with_history(
        self,
        conn,
        request: WebExecutionTaskRequest,
    ):
        entry_id = self.server.command_adapter.prepare_command(
            conn,
            request.command,
            source=request.source,
            should_record=None,
            task_type=request.task_type,
            metadata={key: value for key, value in request.metadata.items() if key != 'operation_id'},
        )

        try:
            task = self.task_store.create_task(
                request.client_id,
                request.command,
                tab_id=request.tab_id,
                session_info=getattr(conn, 'session_info', None),
            )
        except Exception:
            if entry_id:
                try:
                    self.activity_coordinator.discard(conn, entry_id)
                except Exception:
                    # Cleanup must not replace the original task creation failure.
                    pass
            raise

        task['history_entry_id'] = entry_id
        return task

    def _discard_task_setup(self, conn, task: dict):
        task_id = str(task.get('task_id') or '').strip()
        history_entry_id = str(task.get('history_entry_id') or '').strip()
        if task_id:
            self.task_store.delete_task(task_id)
        if history_entry_id:
            try:
                self.activity_coordinator.discard(conn, history_entry_id)
            except Exception:
                # Cleanup must not replace the original submission failure.
                pass

    def _build_task_context(self, conn, task: dict, request: WebExecutionTaskRequest) -> TaskExecutionContext:
        context = TaskExecutionContext.from_task(
            conn,
            task,
            request.command,
            source=request.source,
            task_type=request.task_type,
            metadata=request.metadata,
        )
        context.metadata.update(dict(request.metadata or {}))
        context.control = request.control
        return context

    def _start_task_thread(self, target, *args):
        threading.Thread(
            target=target,
            args=args,
            daemon=True,
        ).start()

    def _acquire_task(self, context: TaskExecutionContext):
        return context.session.acquire_foreground_task(
            task_type=context.task_type,
            command=context.command,
            source=context.source,
            task_id=context.task_id,
            history_entry_id=context.history_entry_id,
            web_task=True,
            tab_id=context.tab_id,
            **({"cancel_policy": context.metadata["cancel_policy"]} if context.metadata.get("cancel_policy") else {}),
        )

    def _ensure_active_task(self, conn, task_id: str):
        foreground_task = conn.get_foreground_task() or {}
        current_task_id = (foreground_task.get('task_id') or '').strip()
        if current_task_id != str(task_id).strip():
            raise ValueError('task is no longer the active foreground task')
        return foreground_task

    def _request_task_cancel(self, conn, task_id: str):
        self.task_store.request_cancel(task_id)
        foreground_task = self._ensure_active_task(conn, task_id)

        cancel_info = conn.request_foreground_task_cancel(task_id=task_id)
        if not cancel_info:
            raise RuntimeError('failed to request task cancellation')

        command_id = cancel_info.get('command_id')
        # During a nested log snapshot this ID targets only that cancellable
        # Control; between snapshots the Server-owned follow stops by flag.
        if command_id:
            conn.send_cancel(command_id)

        result = dict(cancel_info)
        if not result.get('history_entry_id'):
            result['history_entry_id'] = foreground_task.get('history_entry_id') or ''
        return result

    def _resolve_cancellable_task(self, task_id: str):
        task = self.task_store.get_task(task_id)
        if not task:
            raise ValueError('task not found')

        task_status = str(task.get('status') or '').strip()
        if task_status not in ('running', 'cancelling'):
            raise ValueError(f'task is not cancellable: {task_status or "unknown"}')

        client_id = task.get('client_id') or ''
        if not client_id:
            raise ValueError('task client_id is missing')

        conn = self.server.get_target_connection_by_client_id(client_id)
        foreground = self._ensure_active_task(conn, task_id)
        if foreground.get("cancel_policy") == "none":
            raise ValueError("Current execution does not support cancellation")
        return task, conn

    def _resolve_runner(self, runner_name: str):
        runner = getattr(self.task_runner, runner_name, None)
        if not callable(runner):
            raise ValueError(f'unknown task runner: {runner_name}')
        return runner

    def _submit_request(self, request: WebExecutionTaskRequest):
        conn = self.server.get_target_connection_by_client_id(request.client_id)
        runner = self._resolve_runner(request.runner_name)
        task = self._create_task_with_history(conn, request)
        context = self._build_task_context(conn, task, request)
        acquired = False

        try:
            if request.use_foreground_guard:
                self._acquire_task(context)
                acquired = True
            self._start_task_thread(runner, context)
        except Exception:
            if acquired:
                context.session.release_foreground_task(
                    task_id=context.task_id,
                    command=context.command,
                )
            self._discard_task_setup(conn, task)
            raise

        return {
            'task_id': context.task_id,
            'client_id': request.client_id,
            'command': request.command,
            'history_entry_id': context.history_entry_id,
            **({'operation_id': request.metadata['operation_id']} if request.metadata.get('operation_id') else {}),
        }

    def submit_web_command(
            self,
            client_id: str,
            command: str,
            tab_id: str = '',
            metadata: dict | None = None,
            source: str = 'web',
    ):
        return self._submit_request(
            WebExecutionTaskRequest(
                client_id=client_id,
                command=command,
                task_type=TASK_TYPE_COMMAND,
                runner_name='run_command_task',
                tab_id=tab_id,
                source=str(source or 'web').strip() or 'web',
                metadata=dict(metadata or {}),
                # HTTP recovery commands are server-side builtins delivered via a
                # separate HTTP control queue; they never occupy the stuck agent's
                # foreground execution slot.
                use_foreground_guard=not (self._is_http_control_command(command)
                    or self._is_independent_builtin_command(command)),
            )
        )

    def submit_web_control(self, client_id: str, command: str, control: ControlRequest, *,
                           tab_id: str = '', metadata: dict | None = None):
        return self._submit_request(WebExecutionTaskRequest(
            client_id=client_id,
            command=command,
            task_type=TASK_TYPE_COMMAND,
            runner_name='run_control_task',
            tab_id=(tab_id or '').strip(),
            source='web',
            metadata=dict(metadata or {}),
            control=control,
        ))

    @staticmethod
    def _is_independent_builtin_command(command: str) -> bool:
        from server.application.command.server_builtin_registry import SERVER_COMMAND_REGISTRY
        return SERVER_COMMAND_REGISTRY.is_independent_input(command)

    @staticmethod
    def _is_http_control_command(command: str) -> bool:
        try:
            parts = shlex.split(str(command or '').strip())
        except ValueError:
            return False
        return len(parts) == 2 and parts[0] == 'httpctl' and parts[1].lower() in HTTP_CONTROL_COMMANDS

    @staticmethod
    def _is_server_owned_xt_log_follow(command: str) -> bool:
        try:
            parts = shlex.split(str(command or '').strip())
        except ValueError:
            return False
        return (len(parts) == 6 and parts[:3] == ['xt', 'instance', 'logs']
                and parts[-1] in ('--follow', '-f'))

    def cancel_web_task(self, task_id: str):
        task = self.task_store.get_task(task_id)
        transfer = (self.transfer_service.find_active_transfer_by_task_id(task_id)
                    if self.transfer_service is not None else None)
        if task and transfer:
            if task.get('status') not in ('running', 'cancelling'):
                raise ValueError('task is not cancellable')
            if task.get('client_id') != transfer.get('client_id'):
                raise ValueError('transfer does not belong to task client')
            if transfer.get('cancel_supported') is False:
                raise ValueError('current transfer mode does not support cancellation')

            client_id = task.get('client_id') or transfer.get('client_id') or ''
            conn = self.server.get_target_connection_by_client_id(client_id)
            self.task_store.request_cancel(task_id)
            self.transfer_service.mark_cancelling(transfer.get('transfer_id') or '')
            conn.send({
                'type': MSG_TYPE_TRANSFER_CANCEL,
                'transfer_id': transfer.get('transfer_id') or '',
            })
            return {
                'task_id': task_id,
                'client_id': client_id,
                'status': 'cancelling',
                'command_id': None,
                'history_entry_id': task.get('history_entry_id') or '',
                'transfer_id': transfer.get('transfer_id') or '',
            }

        task, conn = self._resolve_cancellable_task(task_id)
        client_id = task.get('client_id') or ''
        cancel_info = self._request_task_cancel(conn, task_id)
        self.activity_coordinator.update_status(
            conn, cancel_info.get('history_entry_id') or '', 'cancelling'
        )
        command_id = cancel_info.get('command_id')

        return {
            'task_id': task_id,
            'client_id': client_id,
            'status': 'cancelling',
            'command_id': command_id,
            'history_entry_id': cancel_info.get('history_entry_id') or '',
        }

    def submit_web_upload(
        self,
        client_id: str,
        local_path: str,
        display_name: str,
        remote_path: str = '',
        tab_id: str = '',
        transfer_id: str = '',
        conflict_policy=None,
        operation_id: str = '',
    ):
        command = f'upload {display_name}'
        return self._submit_request(
            WebExecutionTaskRequest(
                client_id=client_id,
                command=command,
                task_type=TASK_TYPE_UPLOAD,
                runner_name='run_upload_task',
                tab_id=tab_id,
                source='web',
                metadata={
                    'local_path': local_path,
                    'display_name': display_name,
                    'remote_path': remote_path,
                    'upload_tmp_dir': getattr(self.file_service, 'upload_tmp_dir', ''),
                    'transfer_id': (transfer_id or '').strip(),
                    'conflict_policy': conflict_policy,
                    'operation_id': operation_id,
                },
                use_foreground_guard=False,
            )
        )
