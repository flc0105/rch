package handler

import (
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"

	"client-go/executor"
	"client-go/protocol"
)

func pair(t *testing.T) (*executor.Session, *protocol.RATSocket) {
	t.Helper()
	a, b := net.Pipe()
	t.Cleanup(func() { _ = a.Close(); _ = b.Close() })
	return executor.NewSession(protocol.NewRATSocket(a), "test-client"), protocol.NewRATSocket(b)
}

func receive(t *testing.T, peer *protocol.RATSocket) map[string]interface{} {
	t.Helper()
	ch := make(chan map[string]interface{}, 1)
	go func() { v, _ := peer.Recv(); ch <- v }()
	select {
	case v := <-ch:
		if v == nil {
			t.Fatal("socket closed")
		}
		return v
	case <-time.After(3 * time.Second):
		t.Fatal("timed out waiting for protocol result")
	}
	return nil
}

func TestUnsupportedExecutionMessagesReturnFailure(t *testing.T) {
	for _, typ := range []string{"acmd"} {
		t.Run(typ, func(t *testing.T) {
			session, peer := pair(t)
			go Handle(session, map[string]interface{}{"type": typ, "id": float64(27), "text": "script body"})
			v := receive(t, peer)
			if v["type"] != "result" || v["status"] != float64(0) || v["eof"] != float64(1) || v["id"] != float64(27) {
				t.Fatalf("bad failed result: %#v", v)
			}
			if !strings.Contains(v["text"].(string), typ) {
				t.Fatalf("unclear error: %#v", v)
			}
		})
	}
}

func TestUnsupportedControlJobReturnsFailure(t *testing.T) {
	session, peer := pair(t)
	go Handle(session, map[string]interface{}{"type": "control", "id": float64(29),
		"domain": "job", "action": "ps", "payload": map[string]interface{}{}})
	result := receive(t, peer)
	if result["status"] != float64(0) || !strings.Contains(result["text"].(string), "job") {
		t.Fatalf("unexpected unsupported Control result: %#v", result)
	}
}

func TestShellCancelReleasesCommandAndKeepsSocketUsable(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX shell fixture")
	}
	session, peer := pair(t)
	Handle(session, map[string]interface{}{"type": "command", "id": float64(7), "text": "sleep 30"})
	if !session.HasActiveShell() {
		t.Fatal("command not active")
	}
	time.Sleep(150 * time.Millisecond)
	// Cancel must be processed while the command is still running.
	go Handle(session, map[string]interface{}{"type": "cancel", "id": float64(8), "target_id": float64(7)})
	first := receive(t, peer)
	second := receive(t, peer)
	third := receive(t, peer)
	all := []map[string]interface{}{first, second, third}
	accepted, stopped, ended := false, false, false
	for _, v := range all {
		if v["type"] == "cancel_ack" && v["state"] == "accepted" {
			accepted = true
		}
		if v["type"] == "cancel_ack" && v["state"] == "stopped" {
			stopped = true
		}
		if v["type"] == "result" && v["id"] == float64(7) && v["eof"] == float64(1) && v["status"] == float64(0) {
			ended = true
		}
	}
	if !accepted || !stopped || !ended {
		t.Fatalf("cancel incomplete: %#v", all)
	}
	if session.HasActiveShell() {
		t.Fatal("foreground shell was not released")
	}
	go Handle(session, map[string]interface{}{"type": "command", "id": float64(9), "text": "pwd"})
	next := receive(t, peer)
	if next["id"] != float64(9) || next["status"] != float64(1) {
		t.Fatalf("subsequent command failed: %#v", next)
	}
}

func TestNonexistentCancelRejectedWithoutBlocking(t *testing.T) {
	session, peer := pair(t)
	go Handle(session, map[string]interface{}{"type": "cancel", "id": float64(5), "target_id": float64(44)})
	v := receive(t, peer)
	if v["type"] != "cancel_ack" || v["state"] != "rejected" {
		t.Fatalf("bad ack: %#v", v)
	}
}

func TestUnsupportedTransferFinishesWithFailure(t *testing.T) {
	session, peer := pair(t)
	go Handle(session, map[string]interface{}{
		"type": "transfer_start", "transfer_id": "transfer-123", "operation": "unsupported_transfer",
	})
	result := receive(t, peer)
	if result["type"] != "transfer_update" || result["transfer_id"] != "transfer-123" ||
		result["state"] != "failed" || result["stage"] != "failed" || result["cancel_supported"] != false {
		t.Fatalf("unexpected transfer failure message: %#v", result)
	}
	if result["error"] == "" {
		t.Fatalf("transfer failure has no reason: %#v", result)
	}
}

func TestHeartbeatEchoesServerTimestampForRTT(t *testing.T) {
	session, peer := pair(t)
	ts := "2026-11-03T12:30:00.987654"
	go Handle(session, map[string]interface{}{"type": "heartbeat", "id": float64(101), "ts": ts})
	response := receive(t, peer)
	if response["type"] != "heartbeat_ack" || response["server_ts"] != ts || response["id"] != float64(101) {
		t.Fatalf("heartbeat lost timestamp required for RTT: %#v", response)
	}
}

func TestExplicitShellCommandsAvailableAndPreserveQuotedArguments(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX shell fixture")
	}
	for _, cmd := range []string{"shell", "shell_stream"} {
		t.Run(cmd, func(t *testing.T) {
			spec, ok := executor.LookupCommand(cmd)
			if !ok || spec.Runner == nil {
				t.Fatalf("%s is not registered as cancellable command", cmd)
			}
			session, peer := pair(t)
			go Handle(session, map[string]interface{}{"type": "command", "id": float64(51), "text": cmd + ` printf '%s\n' 'a b'`})
			var seen, final bool
			for i := 0; i < 5; i++ {
				msg := receive(t, peer)
				if msg["type"] != "result" {
					t.Fatalf("wrong frame: %#v", msg)
				}
				if strings.Contains(msg["text"].(string), "a b") {
					seen = true
				}
				if msg["eof"] == float64(1) {
					final = true
					if msg["status"] != float64(1) {
						t.Fatalf("command failed: %#v", msg)
					}
					break
				}
			}
			if !seen || !final {
				t.Fatalf("output or final frame missing: seen=%v final=%v", seen, final)
			}
		})
	}
}

func TestShellStreamEmitsBeforeCommandFinishes(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX shell fixture")
	}
	session, peer := pair(t)
	Handle(session, map[string]interface{}{"type": "command", "id": float64(62), "text": `shell_stream printf 'first\n'; sleep 1; printf 'second\n'`})
	start := time.Now()
	first := receive(t, peer)
	if first["eof"] != float64(0) || first["text"] != "first" || time.Since(start) >= 800*time.Millisecond {
		t.Fatalf("first output not streamed before completion: %#v elapsed %v", first, time.Since(start))
	}
	second := receive(t, peer)
	final := receive(t, peer)
	if second["eof"] != float64(0) || second["text"] != "second" || final["eof"] != float64(1) || final["status"] != float64(1) {
		t.Fatalf("wrong stream completion: %#v %#v", second, final)
	}
}

func TestExplicitShellStreamCancellation(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX shell fixture")
	}
	session, peer := pair(t)
	Handle(session, map[string]interface{}{"type": "command", "id": float64(70), "text": "shell_stream sleep 30"})
	time.Sleep(150 * time.Millisecond)
	go Handle(session, map[string]interface{}{"type": "cancel", "id": float64(71), "target_id": float64(70)})
	var accepted, stopped, finished bool
	for i := 0; i < 3; i++ {
		msg := receive(t, peer)
		if msg["type"] == "cancel_ack" && msg["state"] == "accepted" {
			accepted = true
		}
		if msg["type"] == "cancel_ack" && msg["state"] == "stopped" {
			stopped = true
		}
		if msg["type"] == "result" && msg["eof"] == float64(1) && msg["status"] == float64(0) {
			finished = true
		}
	}
	if !accepted || !stopped || !finished || session.HasActiveShell() {
		t.Fatalf("cancel incomplete: accepted=%v stopped=%v finished=%v", accepted, stopped, finished)
	}
}

func TestShellStreamStderrAndFailureCompletion(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX shell fixture")
	}
	session, peer := pair(t)
	Handle(session, map[string]interface{}{"type": "command", "id": float64(80), "text": "shell_stream printf 'bad\\n' >&2; exit 7"})
	first, final := receive(t, peer), receive(t, peer)
	if first["text"] != "bad" || first["status"] != float64(0) || first["eof"] != float64(0) ||
		final["eof"] != float64(1) || final["status"] != float64(0) || !strings.Contains(final["text"].(string), "code 7") {
		t.Fatalf("stderr stream or final status wrong: %#v %#v", first, final)
	}
}

func TestShellMissingArgsReturnsTerminalResult(t *testing.T) {
	for _, name := range []string{"shell", "shell_stream"} {
		session, peer := pair(t)
		Handle(session, map[string]interface{}{"type": "command", "id": float64(91), "text": name})
		result := receive(t, peer)
		if result["status"] != float64(0) || result["eof"] != float64(1) || !strings.Contains(result["text"].(string), "Usage") {
			t.Fatalf("unexpected missing args result: %#v", result)
		}
	}
}

func TestExplicitShellReportsExitCode(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX shell fixture")
	}
	session, peer := pair(t)
	Handle(session, map[string]interface{}{"type": "command", "id": float64(93), "text": "shell printf 'oops\\n'; exit 8"})
	result := receive(t, peer)
	if result["status"] != float64(0) || !strings.Contains(result["text"].(string), "oops") || !strings.Contains(result["text"].(string), "code 8") {
		t.Fatalf("shell did not report error details: %#v", result)
	}
}

func TestShellStreamCancelledAfterRealOutputAndSubsequentCommand(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX shell fixture")
	}
	session, peer := pair(t)
	Handle(session, map[string]interface{}{"type": "command", "id": float64(201), "text": "shell_stream echo ready; sleep 30"})
	first := receive(t, peer)
	if first["type"] != "result" || first["eof"] != float64(0) || first["text"] != "ready" {
		t.Fatalf("expected live output before cancel: %#v", first)
	}
	go Handle(session, map[string]interface{}{"type": "cancel", "id": float64(202), "target_id": float64(201)})
	accepted, stopped, final := false, false, false
	for i := 0; i < 3; i++ {
		msg := receive(t, peer)
		if msg["type"] == "cancel_ack" && msg["state"] == "accepted" {
			accepted = true
		}
		if msg["type"] == "cancel_ack" && msg["state"] == "stopped" {
			stopped = true
		}
		if msg["type"] == "result" && msg["eof"] == float64(1) && msg["status"] == float64(0) {
			final = true
		}
	}
	if !accepted || !stopped || !final || session.HasActiveShell() {
		t.Fatalf("cancel incomplete: %v %v %v", accepted, stopped, final)
	}
	go Handle(session, map[string]interface{}{"type": "command", "id": float64(203), "text": "pwd"})
	next := receive(t, peer)
	if next["id"] != float64(203) || next["status"] != float64(1) {
		t.Fatalf("command after cancel failed: %#v", next)
	}
}

func TestScriptMessageExecutesExternalPythonAndReturnsFinalFrame(t *testing.T) {
	if _, err := exec.LookPath("python3"); err != nil {
		if _, err := exec.LookPath("python"); err != nil {
			t.Skip("no Python interpreter")
		}
	}
	session, peer := pair(t)
	Handle(session, map[string]interface{}{
		"type": "control", "id": float64(90), "domain": "script", "action": "run",
		"payload": map[string]interface{}{"script_name": "demo", "execution_mode": "subprocess_pipe", "output_mode": "stream", "source": "print('hi:' + kwargs['target'])", "params": map[string]interface{}{"target": "folder one"}},
	})
	var chunks []string
	for i := 0; i < 12; i++ {
		result := receive(t, peer)
		if result["id"] != float64(90) || result["type"] != "result" {
			t.Fatalf("invalid script frame: %#v", result)
		}
		if result["eof"] == float64(1) {
			if result["status"] != float64(1) {
				t.Fatalf("script failed: %#v", result)
			}
			if !strings.Contains(strings.Join(chunks, "\n"), "hi:folder one") {
				t.Fatalf("output missing: %#v", chunks)
			}
			return
		}
		chunks = append(chunks, result["text"].(string))
	}
	t.Fatal("script missing EOF frame")
}

func TestScriptBadParametersFailWithoutBreakingSession(t *testing.T) {
	session, peer := pair(t)
	go Handle(session, map[string]interface{}{
		"type": "control", "id": float64(91), "domain": "script", "action": "run",
		"payload": map[string]interface{}{"script_name": "demo", "source": "print('hi')", "params": []string{"wrong"}},
	})
	result := receive(t, peer)
	if result["eof"] != float64(1) || result["status"] != float64(0) || !strings.Contains(result["text"].(string), "script Control") {
		t.Fatalf("unexpected script failure: %#v", result)
	}
	go Handle(session, map[string]interface{}{"type": "command", "id": float64(92), "text": "pwd"})
	next := receive(t, peer)
	if next["eof"] != float64(1) || next["status"] != float64(1) {
		t.Fatalf("command slot not released: %#v", next)
	}
}

func TestRemoteFilesControlTypedDirectoryAndArchive(t *testing.T) {
	dir := t.TempDir()
	session, peer := pair(t)
	makeRequest := func(id int, action string, payload map[string]interface{}) map[string]interface{} {
		go Handle(session, map[string]interface{}{
			"type": "control", "id": float64(id), "domain": "remote_files",
			"action": action, "payload": payload,
		})
		result := receive(t, peer)
		if result["id"] != float64(id) || result["type"] != "result" || result["eof"] != float64(1) {
			t.Fatalf("bad Control reply: %#v", result)
		}
		return result
	}
	newFolder := dir + "/control-dir"
	created := makeRequest(101, "create_directory", map[string]interface{}{"path": newFolder})
	if created["status"] != float64(1) {
		t.Fatalf("mkdir failed: %#v", created)
	}
	browsed := makeRequest(102, "browse_directory", map[string]interface{}{"path": dir, "page": float64(1), "page_size": float64(10)})
	if browsed["status"] != float64(1) {
		t.Fatalf("browse failed: %#v", browsed)
	}
	if _, ok := browsed["data"].(map[string]interface{}); !ok {
		t.Fatalf("browse reply must be structured: %#v", browsed)
	}
	invalid := makeRequest(103, "delete_everything", map[string]interface{}{"path": newFolder})
	if invalid["status"] != float64(0) {
		t.Fatalf("unknown action succeeded: %#v", invalid)
	}
	removed := makeRequest(104, "delete_paths", map[string]interface{}{"paths": []interface{}{newFolder}})
	if removed["status"] != float64(1) {
		t.Fatalf("delete failed: %#v", removed)
	}
}

func TestIndependentBrowseWhileScriptRuns(t *testing.T) {
	if _, err := exec.LookPath("python3"); err != nil {
		if _, err := exec.LookPath("python"); err != nil {
			t.Skip("no Python interpreter")
		}
	}
	session, peer := pair(t)
	Handle(session, map[string]interface{}{"type": "control", "id": float64(101), "domain": "script", "action": "run", "payload": map[string]interface{}{"script_name": "test/probe", "source": "import time\nprint('ready', flush=True)\ntime.sleep(20)", "params": map[string]interface{}{}, "execution_mode": "subprocess_pipe", "output_mode": "stream"}})
	ready := receive(t, peer)
	if ready["id"] != float64(101) || !strings.Contains(ready["text"].(string), "ready") {
		t.Fatalf("bad start: %#v", ready)
	}
	Handle(session, map[string]interface{}{"type": "control", "id": float64(102), "domain": "remote_files", "action": "browse_directory", "payload": map[string]interface{}{"path": t.TempDir()}})
	result := receive(t, peer)
	if result["id"] != float64(102) || result["status"] != float64(1) || !session.HasActiveShell() {
		t.Fatalf("browse lost foreground: %#v", result)
	}
	target := filepath.Join(t.TempDir(), "new-directory")
	Handle(session, map[string]interface{}{"type": "control", "id": float64(104), "domain": "remote_files", "action": "create_directory", "payload": map[string]interface{}{"path": target}})
	result = receive(t, peer)
	if result["id"] != float64(104) || result["status"] != float64(1) || !session.HasActiveShell() {
		t.Fatalf("mkdir lost foreground: %#v", result)
	}
	if info, err := os.Stat(target); err != nil || !info.IsDir() {
		t.Fatalf("mkdir failed: %v", err)
	}
	Handle(session, map[string]interface{}{"type": "control", "id": float64(105), "domain": "configuration", "action": "get", "payload": map[string]interface{}{}})
	result = receive(t, peer)
	if result["id"] != float64(105) || result["status"] != float64(1) || !session.HasActiveShell() {
		t.Fatalf("configuration lost foreground: %#v", result)
	}
	go Handle(session, map[string]interface{}{"type": "cancel", "id": float64(103), "target_id": float64(101)})
	for i := 0; i < 5; i++ {
		frame := receive(t, peer)
		if frame["type"] == "result" && frame["id"] == float64(101) && frame["eof"] == float64(1) {
			if frame["status"] != float64(0) {
				t.Fatalf("cancel failed: %#v", frame)
			}
			return
		}
	}
	t.Fatal("missing cancelled final result")
}
