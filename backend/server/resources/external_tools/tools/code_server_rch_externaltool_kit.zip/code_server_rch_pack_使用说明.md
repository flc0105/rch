# code_server_rch_pack.py 简易使用说明

将 `code_server_rch_pack.py` 与本说明放在同一目录，在该目录打开终端。需要 **Python 3** 和 **curl**；脚本会下载官方 code-server v4.141.0 归档、验证内置 SHA-256，并生成 RCH 使用的 ZIP。

## 1. 自动下载并打包

**macOS Apple Silicon（M 系列芯片）：**

```bash
python3 code_server_rch_pack.py darwin-arm64 --out-dir .
```

**macOS Intel：**

```bash
python3 code_server_rch_pack.py darwin-amd64 --out-dir .
```

**Linux AMD64（x86-64）：**

```bash
python3 code_server_rch_pack.py linux-amd64 --out-dir .
```

**Linux ARM64：**

```bash
python3 code_server_rch_pack.py linux-arm64 --out-dir .
```

> 可以在 Mac 上为 Linux 打包；不要求打包机器与目标 Client 系统相同。

## 2. 已经下载了官方压缩包

以 Linux AMD64 为例，先下载官方 standalone 包：

https://github.com/coder/code-server/releases/download/v4.141.0/code-server-4.141.0-linux-amd64.tar.gz

也可以使用终端下载：

```bash
curl -fL -o code-server-4.141.0-linux-amd64.tar.gz \
  https://github.com/coder/code-server/releases/download/v4.141.0/code-server-4.141.0-linux-amd64.tar.gz
```

然后用本地压缩包生成 RCH ZIP（不会重复下载）：

```bash
python3 code_server_rch_pack.py linux-amd64 \
  --archive code-server-4.141.0-linux-amd64.tar.gz \
  --out-dir .
```

Mac Apple Silicon 对应的本地文件用法：

```bash
python3 code_server_rch_pack.py darwin-arm64 \
  --archive code-server-4.141.0-macos-arm64.tar.gz \
  --out-dir .
```

## 3. 生成文件与 RCH 放置位置

例如选择 `linux-amd64` 后生成：

```text
code-server-v4.141.0-linux-amd64.zip
```

把生成的 ZIP（不要改名）放到 RCH Server 的：

```text
backend/server/resources/external_tools/packages/
```

把配套的 `code-server.json` 放到：

```text
backend/server/resources/external_tools/metas/code-server.json
```

然后在 RCH External Tool Manager 中安装 `code-server` Package，并启动 `code-server.main` Daemon。

## 4. 查看脚本参数

```bash
python3 code_server_rch_pack.py --help
```

**说明：** 该脚本生成的是 RCH 可安装的 ZIP；不是将 code-server 编译成单个可执行文件。目标 Client 首次启动时会自动解压其中的官方目录。默认 IDE 监听 `127.0.0.1:8080`，公网使用时应通过受保护的 HTTPS 反向代理或 SSH 隧道访问，不要直接开放该端口。
