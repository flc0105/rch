#!/usr/bin/env python3
"""Build an RCH ExternalTool ZIP from a verified official code-server tarball.

The ZIP contains the original tar.gz, not an unpacked and flattened tree:
RCH currently extracts ZIP without preserving Unix symlinks and file modes.
The launcher expands the verified upstream tar.gz on first use, preserving both.
"""
import argparse
import hashlib
import os
from pathlib import Path
import subprocess
import tarfile
import zipfile

VERSION = '4.141.0'
# These checksums were checked against the v4.141.0 SourceForge upstream mirror's
# individual asset pages on 2026-10-22. They are pinned values, not a live API.
TARGETS = {
    'darwin-arm64': ('macos-arm64', 'ab45ad960725bdcdfb92998ef54feb2f479079224315ce44a4f49c54093453c9'),
    'darwin-amd64': ('macos-amd64', 'b133e002c2a1a4f22b2ec42c5f233147f342b592e2eadcacc51703a86f447f77'),
    'linux-amd64': ('linux-amd64', '65bcd20b524d03eb1b5adb7f360244599ef0e5b74089a46a982d32c074b97a29'),
    'linux-arm64': ('linux-arm64', 'e5cc78da1d631c6cf6162f9b18eeaa8ee9d3239e1a88bb99d0602cdc5fa1852d'),
}

LAUNCHER = r'''#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUNTIME="$ROOT/code-server-runtime"
if [ ! -x "$RUNTIME/bin/code-server" ]; then
    LOCK="$ROOT/.extract.lock"
    if mkdir "$LOCK" 2>/dev/null; then
        STAGE=''
        cleanup() {
            if [ -n "$STAGE" ] && [ -d "$STAGE" ]; then rm -rf -- "$STAGE"; fi
            rmdir "$LOCK" 2>/dev/null || true
        }
        trap cleanup EXIT HUP INT TERM
        if [ ! -x "$RUNTIME/bin/code-server" ]; then
            STAGE=$(mktemp -d "$ROOT/.extract.XXXXXXXX")
            tar -xzf "$ROOT/upstream.tar.gz" -C "$STAGE" --strip-components=1
            if [ ! -x "$STAGE/bin/code-server" ]; then
                echo 'Missing executable bin/code-server in upstream archive' >&2
                exit 1
            fi
            if [ -e "$RUNTIME" ]; then
                echo "Incomplete runtime directory: $RUNTIME" >&2
                exit 1
            fi
            mv "$STAGE" "$RUNTIME"
            STAGE=''
        fi
        cleanup
        trap - EXIT HUP INT TERM
    else
        attempts=0
        while [ -d "$LOCK" ] && [ ! -x "$RUNTIME/bin/code-server" ]; do
            attempts=$((attempts + 1))
            if [ "$attempts" -ge 120 ]; then
                echo 'Timed out waiting for code-server extraction lock' >&2
                exit 1
            fi
            sleep 1
        done
    fi
fi
if [ ! -x "$RUNTIME/bin/code-server" ]; then
    echo 'code-server extraction did not complete' >&2
    exit 1
fi
exec "$RUNTIME/bin/code-server" "$@"
'''


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def check_archive(path, upstream_stem):
    """Reject unexpected top-level layouts/path traversal before repackaging."""
    main_exec = f'code-server-{VERSION}-{upstream_stem}/bin/code-server'
    found = False
    with tarfile.open(path, 'r:gz') as tar:
        members = tar.getmembers()
        for entry in members:
            name = entry.name
            pieces = Path(name).parts
            if not pieces or pieces[0] != f'code-server-{VERSION}-{upstream_stem}' or '..' in pieces or name.startswith('/'):
                raise ValueError(f'Unexpected or unsafe archive entry: {name}')
            if entry.name == main_exec:
                found = True
        if not found:
            raise ValueError(f'Expected executable not found: {main_exec}')
    return len(members)


def build_zip(archive, target, destination):
    upstream_stem, _ = TARGETS[target]
    count = check_archive(archive, upstream_stem)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, 'w', allowZip64=True) as z:
        info = zipfile.ZipInfo('launch.sh')
        info.create_system = 3
        info.external_attr = (0o100755 << 16)
        z.writestr(info, LAUNCHER.encode('utf-8'))
        # Already compressed, so storing avoids huge recompression and preserves the
        # original upstream tar members, symlinks and executable modes.
        z.write(archive, arcname='upstream.tar.gz', compress_type=zipfile.ZIP_STORED)
    with zipfile.ZipFile(destination) as z:
        if z.testzip() is not None or z.namelist() != ['launch.sh', 'upstream.tar.gz']:
            raise RuntimeError('Built ZIP failed validation')
    return count


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('target', choices=sorted(TARGETS))
    ap.add_argument('--archive', type=Path, help='Use an already downloaded official upstream .tar.gz')
    ap.add_argument('--out-dir', type=Path, default=Path('.'), help='Where to save the RCH ZIP')
    args = ap.parse_args()
    upstream, expected_sha256 = TARGETS[args.target]
    name = f'code-server-{VERSION}-{upstream}.tar.gz'
    url = f'https://github.com/coder/code-server/releases/download/v{VERSION}/{name}'
    archive = args.archive or args.out_dir / name
    if not archive.is_file():
        if args.archive:
            ap.error(f'Archive does not exist: {archive}')
        archive.parent.mkdir(parents=True, exist_ok=True)
        part = archive.with_name(archive.name + '.part')
        print(f'Downloading {url}', flush=True)
        subprocess.run(['curl', '--fail', '--location', '--retry', '3', '--connect-timeout', '20',
                        '--output', str(part), url], check=True)
        os.replace(part, archive)
    actual = digest(archive)
    if actual != expected_sha256:
        raise SystemExit(f'SHA-256 mismatch for {name}\nexpected: {expected_sha256}\nactual:   {actual}')
    output = args.out_dir / f'code-server-v{VERSION}-{args.target}.zip'
    count = build_zip(archive, args.target, output)
    print(f'Validated {count} archive entries')
    print(f'RCH package: {output.resolve()}')
    print(f'RCH package SHA-256: {digest(output)}')
    print('Place this ZIP in the RCH Server external-tools Package directory with no rename.')


if __name__ == '__main__':
    main()
