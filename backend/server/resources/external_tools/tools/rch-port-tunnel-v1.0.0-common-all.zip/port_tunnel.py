"""Standalone TCP port tunnel; no RCH imports or main-socket traffic.

A hub accepts an authenticated control socket plus one data socket per stream.
An agent connects out to that hub. Either side may own the exposed TCP port.
This tool uses plaintext TCP: put the channel inside a trusted network/VPN/TLS
transport before exposing the channel beyond a trusted network.
"""
import argparse
import hmac
import json
import logging
import secrets
import signal
import socket
import struct
import threading
import time

LOG = logging.getLogger('port_tunnel')
MAX_FRAME = 4096
BUFFER = 65536
WAIT = 10
MAX_PENDING = 128
MAX_STREAMS = 256


def read_exact(sock, size):
    data = bytearray()
    while len(data) < size:
        part = sock.recv(size - len(data))
        if not part:
            raise ConnectionError('channel closed during handshake')
        data.extend(part)
    return bytes(data)


def send_frame(sock, packet, lock=None):
    data = json.dumps(packet, separators=(',', ':')).encode('utf-8')
    if not 0 < len(data) <= MAX_FRAME:
        raise ValueError('invalid control frame size')
    frame = struct.pack('!I', len(data)) + data
    if lock:
        with lock:
            sock.sendall(frame)
    else:
        sock.sendall(frame)


def recv_frame(sock):
    length = struct.unpack('!I', read_exact(sock, 4))[0]
    if not 0 < length <= MAX_FRAME:
        raise ValueError('invalid control frame size')
    data = json.loads(read_exact(sock, length))
    if not isinstance(data, dict):
        raise ValueError('invalid control frame')
    return data


def close(sock):
    if sock:
        try:
            sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            sock.close()
        except OSError:
            pass


def listen(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((host, port))
        sock.listen(64)
        sock.settimeout(.25)
        return sock
    except BaseException:
        close(sock)
        raise


def bridge(left, right):
    """Raw byte forwarding with TCP half-close; copied from v29 Tunnel core."""
    def copy(source, target):
        try:
            while True:
                chunk = source.recv(BUFFER)
                if not chunk:
                    break
                target.sendall(chunk)
        except OSError:
            pass
        finally:
            try:
                target.shutdown(socket.SHUT_WR)
            except OSError:
                pass

    worker = threading.Thread(target=copy, args=(left, right), daemon=True)
    worker.start()
    try:
        copy(right, left)
        worker.join()
    finally:
        close(left)
        close(right)


def spawn(fn, *args):
    thread = threading.Thread(target=fn, args=args, daemon=True)
    thread.start()
    return thread


class Pending:
    def __init__(self, front=None):
        self.front = front
        self.target = None
        self.error = False
        self.event = threading.Event()


class Hub:
    def __init__(self, args):
        self.args = args
        self.stop = threading.Event()
        self.lock = threading.RLock()
        self.send_lock = threading.Lock()
        self.control = None
        self.front = None
        self.pending = {}
        self.streams = set()
        self.ingress = None

    def send(self, packet):
        with self.lock:
            control = self.control
        if control is None:
            raise ConnectionError('agent not connected')
        send_frame(control, packet, self.send_lock)

    def _front_loop(self, listener):
        while not self.stop.is_set():
            with self.lock:
                if self.front is not listener or self.control is None:
                    break
            try:
                sock, _ = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            spawn(self._handle_front, sock)

    def _handle_front(self, sock):
        entry = Pending(front=sock)
        stream_id = secrets.token_hex(16)
        with self.lock:
            if self.control is None or len(self.pending) >= MAX_PENDING or len(self.streams) >= MAX_STREAMS:
                close(sock)
                return
            self.pending[stream_id] = entry
        try:
            self.send({'op': 'open', 'id': stream_id})
            if not entry.event.wait(WAIT):
                LOG.warning('stream timed out waiting for agent: %s', stream_id)
        except (OSError, ConnectionError, ValueError) as exc:
            LOG.warning('cannot open target: %s', exc)
        finally:
            with self.lock:
                if self.pending.get(stream_id) is entry:
                    self.pending.pop(stream_id, None)
                    close(sock)
            # Otherwise, the data connection owns this socket and its bridge.

    def _expire_pending(self, stream_id, entry):
        if not self.stop.wait(WAIT + 2):
            with self.lock:
                if self.pending.get(stream_id) is entry:
                    self.pending.pop(stream_id, None)
                    entry.event.set()
                    close(entry.target)

    def _connect_target(self, stream_id, entry):
        target = None
        try:
            target = socket.create_connection((self.args.target_host, self.args.target_port), timeout=WAIT)
            target.settimeout(None)
            with self.lock:
                if self.pending.get(stream_id) is not entry or self.control is None:
                    return
                entry.target = target
                target = None
        except OSError as exc:
            LOG.warning('target connection failed: %s', exc)
            entry.error = True
        finally:
            entry.event.set()
            close(target)

    def _handle_data(self, sock, stream_id):
        if not isinstance(stream_id, str) or len(stream_id) != 32:
            send_frame(sock, {'ok': False})
            return
        with self.lock:
            entry = self.pending.get(stream_id)
        if entry is None:
            send_frame(sock, {'ok': False})
            return
        if entry.front is not None:
            with self.lock:
                if self.pending.get(stream_id) is entry:
                    self.pending.pop(stream_id, None)
                    self.streams.update((entry.front, sock))
                else:
                    send_frame(sock, {'ok': False})
                    return
            entry.event.set()
            try:
                send_frame(sock, {'ok': True})
                bridge(entry.front, sock)
            finally:
                close(entry.front)
                with self.lock:
                    self.streams.difference_update((entry.front, sock))
            return
        if not entry.event.wait(WAIT) or entry.error or entry.target is None:
            with self.lock:
                self.pending.pop(stream_id, None)
            send_frame(sock, {'ok': False})
            return
        with self.lock:
            if self.pending.get(stream_id) is not entry or self.control is None:
                send_frame(sock, {'ok': False})
                return
            self.pending.pop(stream_id, None)
            self.streams.update((entry.target, sock))
        try:
            send_frame(sock, {'ok': True})
            bridge(entry.target, sock)
        finally:
            close(entry.target)
            with self.lock:
                self.streams.difference_update((entry.target, sock))

    def _handle_control(self, sock):
        front = None
        with self.lock:
            if self.control is not None:
                send_frame(sock, {'ok': False, 'error': 'already connected'})
                return
            self.control = sock
        try:
            if self.args.expose_on == 'hub':
                front = listen(self.args.listen_host, self.args.listen_port)
                with self.lock:
                    self.front = front
            send_frame(sock, {'ok': True, 'expose_on': self.args.expose_on,
                              'listen_host': self.args.listen_host, 'listen_port': self.args.listen_port,
                              'target_host': self.args.target_host, 'target_port': self.args.target_port})
            sock.settimeout(None)
            LOG.info('agent connected; exposing on %s', self.args.expose_on)
            if front:
                spawn(self._front_loop, front)
            while not self.stop.is_set():
                packet = recv_frame(sock)
                op, stream_id = packet.get('op'), packet.get('id')
                if not isinstance(stream_id, str) or len(stream_id) != 32:
                    raise ValueError('invalid stream ID')
                if op == 'open' and self.args.expose_on == 'agent':
                    with self.lock:
                        if stream_id in self.pending or len(self.pending) >= MAX_PENDING or len(self.streams) >= MAX_STREAMS:
                            continue
                        entry = Pending()
                        self.pending[stream_id] = entry
                    self.send({'op': 'ready', 'id': stream_id})
                    spawn(self._connect_target, stream_id, entry)
                    spawn(self._expire_pending, stream_id, entry)
                elif op == 'reject' and self.args.expose_on == 'hub':
                    with self.lock:
                        entry = self.pending.pop(stream_id, None)
                    if entry:
                        close(entry.front)
                        entry.event.set()
                else:
                    raise ValueError('unexpected control frame')
        except (OSError, ConnectionError, ValueError) as exc:
            LOG.warning('agent control disconnected: %s', exc)
        finally:
            with self.lock:
                if self.control is sock:
                    self.control = None
                if self.front is front:
                    self.front = None
                pending = tuple(self.pending.values())
                self.pending.clear()
                streams = tuple(self.streams)
                self.streams.clear()
                waiting = tuple(self.waiting.values())
                self.waiting.clear()
            for event in waiting:
                event.set()
            close(front)
            for entry in pending:
                entry.event.set()
                close(entry.front)
                close(entry.target)
            for stream in streams:
                close(stream)

    def _accept(self, sock):
        try:
            sock.settimeout(8)
            hello = recv_frame(sock)
            if not isinstance(hello.get('token'), str) or not hmac.compare_digest(hello['token'], self.args.token):
                send_frame(sock, {'ok': False})
                return
            role = hello.get('role')
            if role == 'control':
                self._handle_control(sock)
            elif role == 'data':
                self._handle_data(sock, hello.get('id'))
            else:
                send_frame(sock, {'ok': False})
        except (OSError, ConnectionError, ValueError, json.JSONDecodeError) as exc:
            LOG.warning('rejected tunnel channel: %s', exc)
        finally:
            close(sock)

    def run(self):
        self.ingress = listen(self.args.channel_host, self.args.channel_port)
        LOG.info('channel listening %s:%d', self.args.channel_host, self.args.channel_port)
        try:
            while not self.stop.is_set():
                try:
                    sock, _ = self.ingress.accept()
                except socket.timeout:
                    continue
                except OSError:
                    if not self.stop.is_set():
                        raise
                    break
                spawn(self._accept, sock)
        finally:
            self.stop.set()
            close(self.ingress)
            with self.lock:
                control = self.control
                front = self.front
            close(control)
            close(front)


class Agent:
    def __init__(self, args):
        self.args = args
        self.stop = threading.Event()
        self.lock = threading.RLock()
        self.send_lock = threading.Lock()
        self.control = None
        self.front = None
        self.streams = set()
        self.mapping = {}
        self.waiting = {}

    def send(self, packet):
        with self.lock:
            control = self.control
        if control is None:
            raise ConnectionError('hub disconnected')
        send_frame(control, packet, self.send_lock)

    def dial(self):
        return socket.create_connection((self.args.hub_host, self.args.channel_port), timeout=WAIT)

    def _data(self, stream_id):
        sock = self.dial()
        try:
            sock.settimeout(WAIT)
            send_frame(sock, {'role': 'data', 'token': self.args.token, 'id': stream_id})
            if recv_frame(sock).get('ok') is not True:
                raise ConnectionError('stream rejected by hub')
            sock.settimeout(None)
            return sock
        except BaseException:
            close(sock)
            raise

    def _target(self, stream_id):
        target = data = None
        try:
            target = socket.create_connection((self.mapping['target_host'], self.mapping['target_port']), timeout=WAIT)
            data = self._data(stream_id)
            target.settimeout(None)
            with self.lock:
                if self.control is None:
                    return
                self.streams.update((target, data))
            bridge(target, data)
        except (OSError, ConnectionError, ValueError) as exc:
            LOG.warning('target failed: %s', exc)
            try:
                self.send({'op': 'reject', 'id': stream_id})
            except (OSError, ConnectionError):
                pass
        finally:
            with self.lock:
                self.streams.discard(target)
                self.streams.discard(data)
            close(target)
            close(data)

    def _handle_front(self, sock):
        data = None
        stream_id = secrets.token_hex(16)
        accepted = threading.Event()
        try:
            with self.lock:
                if self.control is None or len(self.streams) >= MAX_STREAMS:
                    return
                self.streams.add(sock)
                self.waiting[stream_id] = accepted
            self.send({'op': 'open', 'id': stream_id})
            if not accepted.wait(WAIT):
                raise TimeoutError('hub did not acknowledge stream')
            with self.lock:
                if self.control is None:
                    return
            data = self._data(stream_id)
            with self.lock:
                if self.control is None:
                    return
                self.streams.add(data)
            bridge(sock, data)
        except (OSError, ConnectionError, ValueError) as exc:
            LOG.warning('stream failed: %s', exc)
        finally:
            with self.lock:
                self.streams.discard(sock)
                self.streams.discard(data)
                self.waiting.pop(stream_id, None)
            close(sock)
            close(data)

    def _front_loop(self, listener):
        while not self.stop.is_set():
            with self.lock:
                if self.front is not listener or self.control is None:
                    break
            try:
                sock, _ = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            spawn(self._handle_front, sock)

    def _once(self):
        control = self.dial()
        front = None
        try:
            control.settimeout(WAIT)
            send_frame(control, {'role': 'control', 'token': self.args.token})
            mapping = recv_frame(control)
            if mapping.get('ok') is not True:
                raise ConnectionError('hub rejected control connection or token')
            if mapping.get('expose_on') not in ('hub', 'agent'):
                raise ValueError('invalid exposed side')
            for key in ('listen_port', 'target_port'):
                if not isinstance(mapping.get(key), int) or not 0 < mapping[key] <= 65535:
                    raise ValueError('invalid mapping port')
            for key in ('listen_host', 'target_host'):
                if not isinstance(mapping.get(key), str) or not mapping[key]:
                    raise ValueError('invalid mapping host')
            if mapping['expose_on'] == 'agent':
                front = listen(mapping['listen_host'], mapping['listen_port'])
            with self.lock:
                self.control = control
                self.mapping = mapping
                self.front = front
            control.settimeout(None)
            LOG.info('channel connected; exposing on %s', mapping['expose_on'])
            if front:
                spawn(self._front_loop, front)
            while not self.stop.is_set():
                packet = recv_frame(control)
                stream_id = packet.get('id')
                if not isinstance(stream_id, str) or len(stream_id) != 32:
                    raise ValueError('invalid hub control frame')
                if packet.get('op') == 'ready' and mapping['expose_on'] == 'agent':
                    with self.lock:
                        waiting = self.waiting.get(stream_id)
                    if waiting:
                        waiting.set()
                elif packet.get('op') == 'open' and mapping['expose_on'] == 'hub':
                    spawn(self._target, stream_id)
                else:
                    raise ValueError('invalid hub control frame')
        finally:
            with self.lock:
                if self.control is control:
                    self.control = None
                    self.front = None
                streams = tuple(self.streams)
                self.streams.clear()
                waiting = tuple(self.waiting.values())
                self.waiting.clear()
            for event in waiting:
                event.set()
            close(front)
            close(control)
            for sock in streams:
                close(sock)

    def run(self):
        while not self.stop.is_set():
            try:
                self._once()
            except (OSError, ConnectionError, ValueError) as exc:
                LOG.warning('hub disconnected: %s', exc)
            self.stop.wait(2)


def port(value):
    result = int(value)
    if not 1 <= result <= 65535:
        raise argparse.ArgumentTypeError('port must be 1..65535')
    return result


def token(value):
    if not isinstance(value, str) or len(value) < 32 or len(value) > 128 or any(c.isspace() for c in value):
        raise argparse.ArgumentTypeError('token must be 32..128 non-whitespace characters')
    return value


def parse(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='role', required=True)
    hub = sub.add_parser('hub', help='Accept agent channel and configure the mapping')
    hub.add_argument('--channel-host', default='127.0.0.1')
    hub.add_argument('--channel-port', type=port, default=9444)
    hub.add_argument('--expose-on', choices=('hub', 'agent'), default='agent')
    hub.add_argument('--listen-host', default='127.0.0.1')
    hub.add_argument('--listen-port', type=port, required=True)
    hub.add_argument('--target-host', default='127.0.0.1')
    hub.add_argument('--target-port', type=port, required=True)
    agent = sub.add_parser('agent', help='Connect out to the channel hub')
    agent.add_argument('--hub-host', default='127.0.0.1')
    agent.add_argument('--channel-port', type=port, default=9444)
    for subparser in (hub, agent):
        subparser.add_argument('--token', required=True, type=token,
                               help='shared secret, 32..128 characters (visible in process argv)')
    return parser.parse_args(argv)


def main(argv=None):
    args = parse(argv)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(message)s')
    runner = Hub(args) if args.role == 'hub' else Agent(args)

    def stop(_signal, _frame):
        runner.stop.set()
        if isinstance(runner, Hub):
            close(runner.ingress)
        with runner.lock:
            close(runner.control)
            close(runner.front)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    runner.run()


if __name__ == '__main__':
    main()
